-- Seed Roles
INSERT INTO roles (id, name) VALUES 
(1, 'Admin'),
(2, 'Dispatcher'),
(3, 'Fleet Manager'),
(4, 'Safety Officer'),
(5, 'Financial Analyst')
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name;

-- Seed Users (Password is 'Password123' hashed with bcrypt)
-- Hash: $2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei
INSERT INTO users (name, email, password_hash, role_id) VALUES
('Admin User', 'admin@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 1),
('Dispatcher User', 'dispatcher@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 2),
('Fleet Manager User', 'manager@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 3),
('Fleet Manager', 'fleetmanager@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 3),
('Safety Officer User', 'safety@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 4),
('Financial Analyst User', 'finance@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 5)
ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash;

-- Seed Vehicles
INSERT INTO vehicles (registration_number, model, type, status, max_load_capacity, acquisition_cost, current_fuel_level) VALUES
('V-101', 'Ford Transit', 'Van', 'On Trip', 3000.00, 35000.00, 75.00),
('V-102', 'Freightliner Cascadia', 'Semi', 'On Trip', 40000.00, 120000.00, 85.00),
('V-103', 'Isuzu NPR', 'Truck', 'In Shop', 10000.00, 55000.00, 45.00),
('V-104', 'Volvo VNL 860', 'Semi', 'Retired', 45000.00, 140000.00, 0.00),
('V-105', 'Mercedes Benz Sprinter', 'Van', 'Available', 4000.00, 48000.00, 92.50)
ON CONFLICT (registration_number) DO NOTHING;

-- Seed Drivers
INSERT INTO drivers (name, license_number, license_expiry_date, status, safety_score) VALUES
('John Doe', 'DL-982348', '2026-09-15', 'On Trip', 95),
('Jane Smith', 'DL-112349', '2026-07-20', 'On Trip', 88), -- Expiry within 30 days from 2026-07-12
('Bob Johnson', 'DL-876543', '2025-12-01', 'Suspended', 65), -- Expired & Suspended
('Alice Williams', 'DL-554433', '2027-04-12', 'Available', 98)
ON CONFLICT (license_number) DO NOTHING;

-- Seed Trips
INSERT INTO trips (trip_number, vehicle_id, driver_id, source, destination, status, cargo_weight, revenue, start_date, end_date) VALUES
('TRIP-1001', 2, 2, 'Warehouse A', 'Retail Store B', 'Completed', 15000.00, 1200.00, '2026-07-10 08:00:00', '2026-07-10 14:00:00'),
('TRIP-1002', 1, 1, 'Port Terminals', 'Distribution Center', 'Dispatched', 2500.00, 600.00, '2026-07-12 10:00:00', NULL)
ON CONFLICT (trip_number) DO NOTHING;

-- Seed Maintenance Logs
INSERT INTO maintenance_logs (vehicle_id, description, cost, status, logged_at, completed_at) VALUES
(3, 'Brake pad replacement and oil change', 450.00, 'Pending', '2026-07-11 09:30:00', NULL),
(4, 'Transmission overhaul', 2200.00, 'Completed', '2026-05-10 08:00:00', '2026-05-12 16:00:00')
ON CONFLICT DO NOTHING;

-- Seed Fuel Logs
INSERT INTO fuel_logs (vehicle_id, gallons, cost, logged_at) VALUES
(1, 15.5, 45.00, '2026-07-11 15:30:00'),
(2, 120.0, 380.00, '2026-07-11 12:00:00')
ON CONFLICT DO NOTHING;

-- Seed Expenses
INSERT INTO expenses (vehicle_id, category, amount, description, logged_at) VALUES
(2, 'Tolls', 45.00, 'Highway 95 tolls', '2026-07-11 14:00:00'),
(1, 'Permits', 120.00, 'State border entry permit', '2026-07-10 09:00:00')
ON CONFLICT DO NOTHING;
