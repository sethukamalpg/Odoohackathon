const { Client } = require('../backend/node_modules/pg');

const config = {
  host: process.env.PGHOST || 'localhost',
  port: parseInt(process.env.PGPORT || '5432'),
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || 'postgres',
  database: 'transitops',
};

async function runMigration() {
  console.log('Starting TransitOps Spec Migration...');
  const client = new Client(config);
  try {
    await client.connect();
    console.log('Connected to transitops database.');

    // Begin Transaction
    await client.query('BEGIN');

    // 1. Alter vehicles table: add odometer, region
    console.log('Altering vehicles table...');
    await client.query(`
      ALTER TABLE vehicles 
      ADD COLUMN IF NOT EXISTS odometer NUMERIC(12,2) NOT NULL DEFAULT 0.00 CHECK (odometer >= 0)
    `);
    await client.query(`
      ALTER TABLE vehicles 
      ADD COLUMN IF NOT EXISTS region VARCHAR(100) NOT NULL DEFAULT 'North' CHECK (region IN ('North', 'South', 'East', 'West'))
    `);

    // 2. Alter trips table: add planned_distance, alter status CHECK constraint
    console.log('Altering trips table...');
    await client.query(`
      ALTER TABLE trips 
      ADD COLUMN IF NOT EXISTS planned_distance NUMERIC(10,2) NOT NULL DEFAULT 0.00 CHECK (planned_distance >= 0)
    `);
    
    // Drop existing check constraint and add draft support
    await client.query('ALTER TABLE trips DROP CONSTRAINT IF EXISTS trips_status_check');
    await client.query(`
      ALTER TABLE trips 
      ADD CONSTRAINT trips_status_check CHECK (status IN ('Draft', 'Dispatched', 'Completed', 'Cancelled'))
    `);
    await client.query("ALTER TABLE trips ALTER COLUMN status SET DEFAULT 'Draft'");

    // 3. Alter fuel_logs table: rename gallons to liters
    console.log('Altering fuel_logs table...');
    // Check if gallons column exists before renaming
    const colCheck = await client.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'fuel_logs' AND column_name = 'gallons'
    `);
    if (colCheck.rows.length > 0) {
      await client.query('ALTER TABLE fuel_logs RENAME COLUMN gallons TO liters');
    }
    await client.query('ALTER TABLE fuel_logs DROP CONSTRAINT IF EXISTS fuel_logs_gallons_check');
    await client.query(`
      ALTER TABLE fuel_logs 
      ADD CONSTRAINT fuel_logs_liters_check CHECK (liters > 0)
    `);

    // 4. Update and Insert Roles
    console.log('Updating database roles...');
    // Update role ID 3 to 'Fleet Manager'
    await client.query("UPDATE roles SET name = 'Fleet Manager' WHERE id = 3");
    
    // Insert new roles
    await client.query(`
      INSERT INTO roles (id, name) VALUES 
      (4, 'Safety Officer'),
      (5, 'Financial Analyst')
      ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
    `);

    // 5. Seed new users (Password is 'Password123')
    console.log('Seeding compliance test accounts...');
    // Add Safety Officer
    await client.query(`
      INSERT INTO users (name, email, password_hash, role_id) 
      VALUES ('Safety Officer', 'safety@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 4)
      ON CONFLICT (email) DO NOTHING
    `);
    // Add Financial Analyst
    await client.query(`
      INSERT INTO users (name, email, password_hash, role_id) 
      VALUES ('Financial Analyst', 'finance@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 5)
      ON CONFLICT (email) DO NOTHING
    `);
    // Add Fleet Manager
    await client.query(`
      INSERT INTO users (name, email, password_hash, role_id) 
      VALUES ('Fleet Manager', 'fleetmanager@transitops.com', '$2a$10$k6E30nhpQbFfFnNGrEHVEujvPPbqa.gfhBwmu0ada0hAN0ynsFoei', 3)
      ON CONFLICT (email) DO NOTHING
    `);

    await client.query('COMMIT');
    console.log('Spec Migration Applied Successfully!');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Migration failed:', error.message);
    process.exit(1);
  } finally {
    await client.end();
  }
}

runMigration();
