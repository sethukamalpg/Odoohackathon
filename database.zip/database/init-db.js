const fs = require('fs');
const path = require('path');
// Import pg using the module resolved from backend dependencies
const { Client } = require('../backend/node_modules/pg');

const config = {
  host: process.env.PGHOST || 'localhost',
  port: parseInt(process.env.PGPORT || '5432'),
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || 'postgres',
};

async function initDB() {
  console.log('--- TransitOps Database Initializer ---');
  
  // 1. Connect to default 'postgres' database to check/create 'transitops' database
  const clientDefault = new Client({ ...config, database: 'postgres' });
  try {
    await clientDefault.connect();
    console.log('Connected to default PostgreSQL database.');
    
    // Check if database exists
    const dbCheck = await clientDefault.query("SELECT 1 FROM pg_database WHERE datname = 'transitops'");
    if (dbCheck.rows.length === 0) {
      console.log("Database 'transitops' not found. Creating database...");
      await clientDefault.query('CREATE DATABASE transitops');
      console.log("Database 'transitops' created successfully.");
    } else {
      console.log("Database 'transitops' already exists.");
    }
  } catch (error) {
    console.error('Error checking/creating database:', error.message);
    console.log('\nPlease make sure your local PostgreSQL server is running and the credentials match.');
    process.exit(1);
  } finally {
    await clientDefault.end();
  }

  // 2. Connect to the 'transitops' database and execute schema + seeds
  const clientTransit = new Client({ ...config, database: 'transitops' });
  try {
    await clientTransit.connect();
    console.log("Connected to 'transitops' database.");

    // Read and run schema
    console.log('Applying database schemas...');
    const schemaPath = path.join(__dirname, 'schema.sql');
    const schemaSQL = fs.readFileSync(schemaPath, 'utf8');
    await clientTransit.query(schemaSQL);
    console.log('Schema applied successfully.');

    // Read and run seeds
    console.log('Injecting seed data...');
    const seedPath = path.join(__dirname, 'seed.sql');
    const seedSQL = fs.readFileSync(seedPath, 'utf8');
    await clientTransit.query(seedSQL);
    console.log('Seed data injected successfully.');

    console.log('\n=============================================');
    console.log('Database initialization completed successfully!');
    console.log('=============================================');
  } catch (error) {
    console.error('Error applying schema/seed:', error.message);
    process.exit(1);
  } finally {
    await clientTransit.end();
  }
}

initDB();
