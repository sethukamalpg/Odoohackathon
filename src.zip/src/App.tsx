import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import VehicleRegistry from './pages/VehicleRegistry';
import Drivers from './pages/Drivers';
import TripDispatcher from './pages/TripDispatcher';
import Maintenance from './pages/Maintenance';
import FuelExpense from './pages/FuelExpense';
import Reports from './pages/Reports';
import Settings from './pages/Settings';

// Sidebar
import Sidebar from './components/Sidebar';

// Route guards
const ProtectedLayout: React.FC = () => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-darkBg text-gray-400">
        <div className="flex flex-col items-center gap-2.5">
          <div className="w-8 h-8 border-4 border-brand-amber border-t-transparent rounded-full animate-spin" />
          <p className="text-[10px] uppercase font-bold tracking-widest text-gray-500">Establishing Connection...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-brand-darkBg">
      {/* Navigation Sidebar */}
      <Sidebar />
      
      {/* Content pane */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <Routes>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/vehicles" element={<VehicleRegistry />} />
          <Route path="/drivers" element={<Drivers />} />
          <Route path="/dispatch" element={<TripDispatcher />} />
          <Route path="/maintenance" element={<Maintenance />} />
          <Route path="/expenses" element={<FuelExpense />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/*" element={<ProtectedLayout />} />
          </Routes>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  );
};

export default App;
