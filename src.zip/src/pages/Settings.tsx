import React, { useEffect, useState } from 'react';
import { fetchUsersWithRoles, updateUserRole, type UserRoleMapping } from '../api/settings';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { DataTable, type Column } from '../components/DataTable';
import { Loader2, ShieldAlert, Check, X, ShieldCheck, UserCog } from 'lucide-react';

export const Settings: React.FC = () => {
  const [users, setUsers] = useState<UserRoleMapping[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const { user, hasRole } = useAuth();
  const { showToast } = useToast();

  const loadUsers = async () => {
    try {
      const userList = await fetchUsersWithRoles();
      setUsers(userList);
    } catch (err: any) {
      showToast(err.message || 'Failed to fetch user profiles database.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (hasRole(['Admin'])) {
      loadUsers();
    } else {
      setLoading(false);
    }
  }, []);

  const handleRoleChange = async (userId: number, newRoleId: number) => {
    // Prevent demoting yourself
    if (user && userId === user.id) {
      showToast('You cannot change your own permission role to avoid lockouts.', 'error');
      return;
    }

    setActionLoading(userId);
    try {
      await updateUserRole(userId, newRoleId);
      showToast('User permission role updated successfully.', 'success');
      loadUsers();
    } catch (err: any) {
      showToast(err.message || 'Failed to update user role.', 'error');
    } finally {
      setActionLoading(null);
    }
  };

  // Static Role-Permission Matrix definitions for visual display
  const permissionsMatrix = [
    { permission: 'Register & Edit Fleet Vehicles', admin: true, manager: true, dispatcher: false },
    { permission: 'Delete Fleet Vehicles', admin: true, manager: false, dispatcher: false },
    { permission: 'Manage Operators / Drivers', admin: true, manager: true, dispatcher: false },
    { permission: 'Dispatch Cargo Trips', admin: true, manager: false, dispatcher: true },
    { permission: 'Complete & Cancel Trips', admin: true, manager: false, dispatcher: true },
    { permission: 'Log Service/Maintenance tickets', admin: true, manager: true, dispatcher: true },
    { permission: 'Complete Maintenance tickets', admin: true, manager: true, dispatcher: true },
    { permission: 'Log Fuel Purchases & Expenses', admin: true, manager: true, dispatcher: true },
    { permission: 'View Reports & Business Analytics', admin: true, manager: true, dispatcher: false },
    { permission: 'Configure RBAC System Settings', admin: true, manager: false, dispatcher: false },
  ];

  // If user is not Admin, restrict page access
  if (!hasRole(['Admin'])) {
    return (
      <div className="flex-1 bg-brand-darkBg min-h-screen p-6 md:p-8 flex items-center justify-center">
        <div className="bg-brand-panel border border-gray-800/80 rounded-xl p-8 max-w-md text-center shadow-2xl">
          <ShieldAlert size={42} className="text-rose-500 mx-auto mb-4 animate-bounce" />
          <h3 className="text-lg font-bold font-heading text-white uppercase tracking-wide">Command Access Denied</h3>
          <p className="text-xs text-gray-400 mt-2 leading-relaxed">
            This module controls security settings and role-based permissions matrix access. Please contact the lead platform administrator for clearance.
          </p>
        </div>
      </div>
    );
  }

  const columns: Column<UserRoleMapping>[] = [
    { key: 'name', label: 'Operator Name', sortable: true },
    { key: 'email', label: 'Database Access Email', sortable: true },
    {
      key: 'created_at',
      label: 'Authorized Since',
      sortable: true,
      render: (row) => <span>{new Date(row.created_at).toLocaleDateString()}</span>,
    },
    {
      key: 'role',
      label: 'Authorized Role',
      render: (row) => {
        const isSelf = user && row.id === user.id;

        return (
          <div className="relative flex items-center gap-2">
            <select
              value={row.role_id}
              disabled={isSelf || actionLoading === row.id}
              onChange={(e) => handleRoleChange(row.id, parseInt(e.target.value))}
              className="bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-2.5 py-1.5 text-xs text-gray-300 font-semibold focus:outline-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <option value={1}>Admin</option>
              <option value={2}>Dispatcher</option>
              <option value={3}>Manager</option>
            </select>
            {actionLoading === row.id && <Loader2 size={12} className="animate-spin text-brand-amber" />}
            {isSelf && <span className="text-[10px] text-gray-500 uppercase font-bold">(Your Session)</span>}
          </div>
        );
      },
    },
  ];

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <Loader2 className="animate-spin text-brand-amber" size={32} />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow">
      {/* Page Title */}
      <div className="mb-8">
        <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest font-heading">Security Control</span>
        <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-0.5">Settings & RBAC</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Left Side: Users Access list (Col span 2) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-brand-panel border border-gray-800/60 rounded-xl px-5 py-4 shadow-xl flex items-center gap-3">
            <div className="p-2 bg-brand-amber/10 rounded-lg text-brand-amber border border-brand-amber/20">
              <UserCog size={18} />
            </div>
            <div>
              <h3 className="font-heading font-bold text-white text-sm uppercase tracking-wide leading-tight">Access Control list</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase mt-0.5">Define employee authority ranks</p>
            </div>
          </div>

          <DataTable
            columns={columns}
            data={users}
            searchKey="name"
            searchPlaceholder="Search operator by name..."
          />
        </div>

        {/* Right Side: Permissions Matrix representation (Col span 1) */}
        <div className="bg-brand-panel border border-gray-800/60 rounded-xl p-5 shadow-xl">
          <h3 className="font-heading font-bold text-white text-base tracking-wide uppercase mb-4 flex items-center gap-2">
            <ShieldCheck size={16} className="text-brand-teal stroke-[2.5]" />
            <span>Authority Rank Matrix</span>
          </h3>

          <div className="space-y-4">
            {/* Headers */}
            <div className="grid grid-cols-5 text-[9px] uppercase font-bold text-gray-500 pb-2 border-b border-gray-800">
              <span className="col-span-2">Module Action</span>
              <span className="text-center">ADM</span>
              <span className="text-center">MGR</span>
              <span className="text-center">DIS</span>
            </div>

            {/* Matrix row loops */}
            <div className="space-y-3.5">
              {permissionsMatrix.map((item, idx) => (
                <div key={idx} className="grid grid-cols-5 items-center text-xs font-semibold text-gray-300">
                  <span className="col-span-2 text-gray-400 leading-tight">{item.permission}</span>
                  
                  {/* Admin Check */}
                  <span className="flex justify-center">
                    {item.admin ? (
                      <Check size={14} className="text-brand-teal" />
                    ) : (
                      <X size={14} className="text-rose-500" />
                    )}
                  </span>

                  {/* Manager Check */}
                  <span className="flex justify-center">
                    {item.manager ? (
                      <Check size={14} className="text-brand-teal" />
                    ) : (
                      <X size={14} className="text-rose-500" />
                    )}
                  </span>

                  {/* Dispatcher Check */}
                  <span className="flex justify-center">
                    {item.dispatcher ? (
                      <Check size={14} className="text-brand-teal" />
                    ) : (
                      <X size={14} className="text-rose-500" />
                    )}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Settings;
