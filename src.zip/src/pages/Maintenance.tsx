import React, { useEffect, useState } from 'react';
import { fetchMaintenanceLogs, createMaintenanceLog, closeMaintenanceLog, type MaintenanceLog } from '../api/maintenance';
import { fetchVehicles, type Vehicle } from '../api/vehicles';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { DataTable, type Column } from '../components/DataTable';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Loader2, Plus, Info, Wrench, CheckCircle } from 'lucide-react';

export const Maintenance: React.FC = () => {
  const [logs, setLogs] = useState<MaintenanceLog[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const { hasRole } = useAuth();
  const { showToast } = useToast();

  // Modals state
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [isResolveModalOpen, setIsResolveModalOpen] = useState(false);
  const [activeLogId, setActiveLogId] = useState<number | null>(null);

  // Form Fields
  const [vehicleId, setVehicleId] = useState('');
  const [description, setDescription] = useState('');
  const [cost, setCost] = useState('');
  const [status, setStatus] = useState<'Pending' | 'In Progress'>('Pending');
  const [resolveCost, setResolveCost] = useState('');
  const [formError, setFormError] = useState('');

  // Load logs and vehicles
  const loadData = async () => {
    try {
      const logList = await fetchMaintenanceLogs();
      setLogs(logList);

      const vehicleList = await fetchVehicles();
      // Exclude retired vehicles from new maintenance logs
      setVehicles(vehicleList.filter((v) => v.status !== 'Retired'));
    } catch (err: any) {
      showToast(err.message || 'Failed to fetch maintenance registry.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openLogModal = () => {
    setVehicleId('');
    setDescription('');
    setCost('');
    setStatus('Pending');
    setFormError('');
    setIsLogModalOpen(true);
  };

  const openResolveModal = (id: number, currentCost: number) => {
    setActiveLogId(id);
    setResolveCost(currentCost.toString());
    setFormError('');
    setIsResolveModalOpen(true);
  };

  const handleLogSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!vehicleId) {
      setFormError('Please select a vehicle.');
      return;
    }
    if (!description.trim()) {
      setFormError('Please enter a work description.');
      return;
    }
    if (cost && parseFloat(cost) < 0) {
      setFormError('Please enter a valid cost.');
      return;
    }

    setActionLoading(true);
    try {
      await createMaintenanceLog({
        vehicle_id: parseInt(vehicleId),
        description: description.trim(),
        cost: cost ? parseFloat(cost) : 0,
        status,
      });

      showToast('Maintenance ticket logged. Vehicle status flipped to In Shop.', 'success');
      setIsLogModalOpen(false);
      loadData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create service log.');
      showToast(err.message || 'Failed to log maintenance.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleResolveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeLogId) return;

    if (!resolveCost || parseFloat(resolveCost) < 0) {
      showToast('Please enter a valid final cost.', 'error');
      return;
    }

    setActionLoading(true);
    try {
      await closeMaintenanceLog(activeLogId, parseFloat(resolveCost));
      showToast('Maintenance completed. Vehicle restored to Available.', 'success');
      setIsResolveModalOpen(false);
      loadData();
    } catch (err: any) {
      showToast(err.message || 'Failed to close maintenance log.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const canEdit = hasRole(['Admin', 'Manager', 'Dispatcher']);

  const columns: Column<MaintenanceLog>[] = [
    {
      key: 'registration_number',
      label: 'Vehicle',
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-xs text-white bg-gray-800 px-2 py-0.5 rounded">{row.registration_number}</span>,
    },
    { key: 'vehicle_model', label: 'Model', sortable: true },
    { key: 'description', label: 'Service Description' },
    {
      key: 'cost',
      label: 'Cost',
      sortable: true,
      render: (row) => <span>${parseFloat(row.cost.toString()).toLocaleString()}</span>,
    },
    {
      key: 'logged_at',
      label: 'Logged At',
      sortable: true,
      render: (row) => <span>{new Date(row.logged_at).toLocaleDateString()}</span>,
    },
    {
      key: 'completed_at',
      label: 'Completed At',
      sortable: true,
      render: (row) => <span>{row.completed_at ? new Date(row.completed_at).toLocaleDateString() : '—'}</span>,
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (row) => <StatusBadge status={row.status} />,
    },
    {
      key: 'actions',
      label: 'Action',
      render: (row) => (
        <div>
          {row.status !== 'Completed' && canEdit ? (
            <button
              onClick={() => openResolveModal(row.id, row.cost)}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
            >
              <CheckCircle size={12} />
              <span>Complete</span>
            </button>
          ) : row.status === 'Completed' ? (
            <span className="text-xs text-gray-500 font-semibold uppercase">Resolved</span>
          ) : (
            <span className="text-xs text-gray-600 font-semibold uppercase">Locked</span>
          )}
        </div>
      ),
    },
  ];

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <Loader2 className="animate-spin text-brand-amber" size={32} />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest font-heading">Maintenance Control</span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-0.5">Service Log Tickets</h2>
        </div>
        {canEdit && (
          <button
            onClick={openLogModal}
            className="flex items-center gap-2 bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-4 py-2.5 rounded-xl text-xs font-bold font-heading uppercase tracking-wider shadow-lg shadow-brand-amber/10 transition-all hover:scale-[1.02]"
          >
            <Plus size={15} />
            <span>Create Ticket</span>
          </button>
        )}
      </div>

      {/* Main Datatable */}
      <DataTable
        columns={columns}
        data={logs}
        searchKey="registration_number"
        searchPlaceholder="Filter by registration number..."
        filterOptions={[
          {
            key: 'status',
            label: 'Filter Status',
            options: [
              { label: 'Pending', value: 'Pending' },
              { label: 'In Progress', value: 'In Progress' },
              { label: 'Completed', value: 'Completed' },
            ],
          },
        ]}
      />

      {/* Log Ticket Modal */}
      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="Log Service Ticket"
      >
        <form onSubmit={handleLogSubmit} className="space-y-4">
          {formError && (
            <div className="bg-rose-500/15 border border-rose-500/30 text-rose-400 p-3 rounded-lg text-xs font-semibold flex items-center gap-2">
              <Info size={14} className="shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Select Vehicle</label>
            <select
              value={vehicleId}
              onChange={(e) => setVehicleId(e.target.value)}
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
            >
              <option value="">Choose Asset</option>
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.registration_number} - {v.model} ({v.status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Work Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Detail mechanical problems, parts required, or service description..."
              rows={3}
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Estimated Cost ($)</label>
              <input
                type="number"
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                placeholder="e.g. 350"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Ticket Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
              </select>
            </div>
          </div>

          <div className="border-t border-gray-800/80 pt-4 flex justify-end gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsLogModalOpen(false)}
              className="px-4 py-2.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-5 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {actionLoading && <Loader2 size={13} className="animate-spin" />}
              <span>Initialize Ticket</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* Resolve Ticket Modal */}
      <Modal
        isOpen={isResolveModalOpen}
        onClose={() => setIsResolveModalOpen(false)}
        title="Resolve Maintenance Ticket"
      >
        <form onSubmit={handleResolveSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Final Service Cost ($)</label>
            <input
              type="number"
              value={resolveCost}
              onChange={(e) => setResolveCost(e.target.value)}
              placeholder="e.g. 420"
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
            />
          </div>

          <div className="border-t border-gray-800/80 pt-4 flex justify-end gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsResolveModalOpen(false)}
              className="px-4 py-2.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-5 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {actionLoading && <Loader2 size={13} className="animate-spin" />}
              <span>Complete Ticket</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
export default Maintenance;
