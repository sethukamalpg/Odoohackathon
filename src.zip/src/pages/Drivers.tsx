import React, { useEffect, useState } from 'react';
import { fetchDrivers, createDriver, updateDriver, deleteDriver, type Driver } from '../api/drivers';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { DataTable, type Column } from '../components/DataTable';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Plus, Edit2, Trash2, Loader2, Info, AlertTriangle } from 'lucide-react';

export const Drivers: React.FC = () => {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const { hasRole } = useAuth();
  const { showToast } = useToast();

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [licenseExpiry, setLicenseExpiry] = useState('');
  const [status, setStatus] = useState<'Available' | 'On Trip' | 'Suspended'>('Available');
  const [safetyScore, setSafetyScore] = useState('100');
  const [formError, setFormError] = useState('');

  // Load Drivers
  const loadDrivers = async () => {
    try {
      const data = await fetchDrivers();
      setDrivers(data);
    } catch (err: any) {
      showToast(err.message || 'Failed to load driver rosters.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDrivers();
  }, []);

  const openAddModal = () => {
    setSelectedDriver(null);
    setName('');
    setLicenseNumber('');
    setLicenseExpiry('');
    setStatus('Available');
    setSafetyScore('100');
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (driver: Driver) => {
    setSelectedDriver(driver);
    setName(driver.name);
    setLicenseNumber(driver.license_number);
    // Format date string to yyyy-MM-dd
    const formattedDate = driver.license_expiry_date.split('T')[0];
    setLicenseExpiry(formattedDate);
    setStatus(driver.status);
    setSafetyScore(driver.safety_score.toString());
    setFormError('');
    setIsModalOpen(true);
  };

  const handleFormValidation = () => {
    if (!name.trim()) {
      setFormError('Please enter the driver name.');
      return false;
    }
    if (!licenseNumber.trim()) {
      setFormError('Please enter the driver license number.');
      return false;
    }
    if (!licenseExpiry) {
      setFormError('Please enter the driver license expiry date.');
      return false;
    }
    const score = parseInt(safetyScore);
    if (isNaN(score) || score < 0 || score > 100) {
      setFormError('Safety score must be between 0 and 100.');
      return false;
    }
    setFormError('');
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!handleFormValidation()) return;

    setActionLoading(true);
    const driverData = {
      name: name.trim(),
      license_number: licenseNumber.trim().toUpperCase(),
      license_expiry_date: licenseExpiry,
      status,
      safety_score: parseInt(safetyScore),
    };

    try {
      if (selectedDriver) {
        await updateDriver(selectedDriver.id, driverData);
        showToast('Driver profile updated successfully.', 'success');
      } else {
        await createDriver(driverData);
        showToast('New driver profile registered.', 'success');
      }
      setIsModalOpen(false);
      loadDrivers();
    } catch (err: any) {
      setFormError(err.message || 'Operation failed. Verify parameters.');
      showToast(err.message || 'Failed to submit driver details.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Are you sure you want to remove this driver profile from database?')) return;
    
    try {
      await deleteDriver(id);
      showToast('Driver profile deleted successfully.', 'success');
      loadDrivers();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete driver.', 'error');
    }
  };

  // Checks if expiry is within 30 days (or past)
  const isLicenseExpiringSoon = (dateString: string) => {
    const expiry = new Date(dateString);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 30;
  };

  // Rendering Safety Score Circular Progress Ring
  const renderSafetyRing = (score: number) => {
    const strokeDash = `${score}, 100`;
    // Color transitions based on score
    const colorClass = score >= 90 
      ? 'text-brand-teal' 
      : score >= 75 
        ? 'text-brand-amber' 
        : 'text-rose-500';

    return (
      <div className="flex items-center gap-2">
        <svg className="w-9 h-9 shrink-0 transform -rotate-90" viewBox="0 0 36 36">
          <circle
            className="text-gray-800"
            strokeWidth="3"
            stroke="currentColor"
            fill="none"
            cx="18"
            cy="18"
            r="15.915"
          />
          <circle
            className={colorClass}
            strokeDasharray={strokeDash}
            strokeWidth="3.5"
            strokeLinecap="round"
            stroke="currentColor"
            fill="none"
            cx="18"
            cy="18"
            r="15.915"
          />
          <text 
            x="18" 
            y="21" 
            className="text-[9px] font-bold fill-white font-heading transform rotate-90 origin-center" 
            textAnchor="middle"
          >
            {score}
          </text>
        </svg>
      </div>
    );
  };

  // RBAC checks
  const canEdit = hasRole(['Admin', 'Manager']);
  const canDelete = hasRole(['Admin']);

  // Table Columns
  const columns: Column<Driver>[] = [
    { key: 'name', label: 'Driver Name', sortable: true },
    {
      key: 'license_number',
      label: 'License Number',
      sortable: true,
      render: (row) => <span className="font-mono text-xs text-gray-300 font-semibold">{row.license_number}</span>,
    },
    {
      key: 'license_expiry_date',
      label: 'License Expiry',
      sortable: true,
      render: (row) => {
        const expiringSoon = isLicenseExpiringSoon(row.license_expiry_date);
        const dateStr = new Date(row.license_expiry_date).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
        });

        return (
          <div className="flex items-center gap-1.5 font-semibold">
            {expiringSoon ? (
              <span className="inline-flex items-center gap-1 text-rose-400 font-bold bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded text-xs">
                <AlertTriangle size={12} className="stroke-[2.5]" />
                <span>{dateStr}</span>
              </span>
            ) : (
              <span className="text-gray-300">{dateStr}</span>
            )}
          </div>
        );
      },
    },
    {
      key: 'safety_score',
      label: 'Safety Profile',
      sortable: true,
      render: (row) => renderSafetyRing(row.safety_score),
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (row) => <StatusBadge status={row.status} />,
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (row) => (
        <div className="flex gap-2.5">
          {canEdit && (
            <button
              onClick={() => openEditModal(row)}
              className="text-gray-400 hover:text-brand-amber transition-colors p-1"
              title="Edit Profile"
            >
              <Edit2 size={14} />
            </button>
          )}
          {canDelete && (
            <button
              onClick={() => handleDelete(row.id)}
              className="text-gray-400 hover:text-rose-500 transition-colors p-1"
              title="Delete Profile"
            >
              <Trash2 size={14} />
            </button>
          )}
          {!canEdit && <span className="text-xs text-gray-600 font-semibold uppercase">Read-only</span>}
        </div>
      ),
    },
  ];

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <Loader2 className="animate-spin text-brand-amber" size={32} />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest font-heading">Team Rosters</span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-0.5">Drivers & Safety Profiles</h2>
        </div>
        {canEdit && (
          <button
            onClick={openAddModal}
            className="flex items-center gap-2 bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-4 py-2.5 rounded-xl text-xs font-bold font-heading uppercase tracking-wider shadow-lg shadow-brand-amber/10 transition-all hover:scale-[1.02]"
          >
            <Plus size={15} />
            <span>Add Driver</span>
          </button>
        )}
      </div>

      {/* Main Grid table */}
      <DataTable
        columns={columns}
        data={drivers}
        searchKey="name"
        searchPlaceholder="Search driver by name..."
        filterOptions={[
          {
            key: 'status',
            label: 'Filter Status',
            options: [
              { label: 'Available', value: 'Available' },
              { label: 'On Trip', value: 'On Trip' },
              { label: 'Suspended', value: 'Suspended' },
            ],
          },
        ]}
      />

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={selectedDriver ? 'Update Driver Profile' : 'Register New Fleet Operator'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && (
            <div className="bg-rose-500/15 border border-rose-500/30 text-rose-400 p-3 rounded-lg text-xs font-semibold flex items-center gap-2">
              <Info size={14} className="shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Driver Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. John Doe"
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">License Number</label>
              <input
                type="text"
                value={licenseNumber}
                onChange={(e) => setLicenseNumber(e.target.value)}
                placeholder="e.g. DL-98342"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">License Expiry Date</label>
              <input
                type="date"
                value={licenseExpiry}
                onChange={(e) => setLicenseExpiry(e.target.value)}
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Driver Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="Available">Available</option>
                <option value="On Trip">On Trip</option>
                <option value="Suspended">Suspended</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Safety Rating (0-100)</label>
              <input
                type="number"
                value={safetyScore}
                onChange={(e) => setSafetyScore(e.target.value)}
                min="0"
                max="100"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="border-t border-gray-800/80 pt-4 flex justify-end gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-5 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {actionLoading && <Loader2 size={13} className="animate-spin" />}
              <span>{selectedDriver ? 'Save Profile' : 'Register Operator'}</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
export default Drivers;
