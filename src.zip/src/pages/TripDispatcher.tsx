import React, { useEffect, useState } from 'react';
import { fetchTrips, dispatchTrip, completeTrip, cancelTrip, dispatchDraftTrip, type Trip } from '../api/trips';
import { fetchEligibleVehicles, type Vehicle } from '../api/vehicles';
import { fetchEligibleDrivers, type Driver } from '../api/drivers';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Loader2, Plus, Info, Navigation, Navigation2, CheckCircle, Ban, AlertTriangle } from 'lucide-react';


export const TripDispatcher: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [eligibleVehicles, setEligibleVehicles] = useState<Vehicle[]>([]);
  const [eligibleDrivers, setEligibleDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const { hasRole } = useAuth();
  const { showToast } = useToast();

  // Create Form State
  const [tripNumber, setTripNumber] = useState('');
  const [vehicleId, setVehicleId] = useState('');
  const [driverId, setDriverId] = useState('');
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [cargoWeight, setCargoWeight] = useState('');
  const [plannedDistance, setPlannedDistance] = useState('');
  const [startStatus, setStartStatus] = useState<'Draft' | 'Dispatched'>('Dispatched');
  const [formError, setFormError] = useState('');
  
  // Selected vehicle details for live capacity check
  const [selectedVehicleObj, setSelectedVehicleObj] = useState<Vehicle | null>(null);

  // Complete Trip modal state
  const [isCompleteModalOpen, setIsCompleteModalOpen] = useState(false);
  const [activeTripToComplete, setActiveTripToComplete] = useState<number | null>(null);
  const [tripRevenue, setTripRevenue] = useState('');
  const [finalOdometer, setFinalOdometer] = useState('');
  const [fuelConsumed, setFuelConsumed] = useState('');

  // Load Trips & Dispatch resources
  const loadResources = async () => {
    try {
      const tripList = await fetchTrips();
      setTrips(tripList);

      const vehicles = await fetchEligibleVehicles();
      setEligibleVehicles(vehicles);

      const drivers = await fetchEligibleDrivers();
      setEligibleDrivers(drivers);
    } catch (err: any) {
      showToast(err.message || 'Failed to load dispatch telemetry.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadResources();
  }, []);

  // Update selected vehicle details when selected
  useEffect(() => {
    if (!vehicleId) {
      setSelectedVehicleObj(null);
      return;
    }
    const matched = eligibleVehicles.find((v) => v.id === parseInt(vehicleId));
    setSelectedVehicleObj(matched || null);
  }, [vehicleId, eligibleVehicles]);

  // Live weight check
  const isWeightOverLimit = () => {
    if (!cargoWeight || !selectedVehicleObj) return false;
    return parseFloat(cargoWeight) > parseFloat(selectedVehicleObj.max_load_capacity.toString());
  };

  // Submit dispatch
  const handleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!tripNumber.trim()) {
      setFormError('Please enter a trip reference number.');
      return;
    }
    if (!vehicleId) {
      setFormError('Please select a vehicle.');
      return;
    }
    if (!driverId) {
      setFormError('Please select a driver.');
      return;
    }
    if (!source.trim()) {
      setFormError('Please enter the starting dispatch location.');
      return;
    }
    if (!destination.trim()) {
      setFormError('Please enter the delivery destination.');
      return;
    }
    if (!cargoWeight || parseFloat(cargoWeight) <= 0) {
      setFormError('Please enter a valid cargo weight.');
      return;
    }
    if (!plannedDistance || parseFloat(plannedDistance) < 0) {
      setFormError('Please enter a valid planned distance.');
      return;
    }

    if (isWeightOverLimit()) {
      setFormError('Cargo weight exceeds vehicle capacity limits.');
      return;
    }

    setActionLoading(true);
    try {
      await dispatchTrip({
        trip_number: tripNumber.trim().toUpperCase(),
        vehicle_id: parseInt(vehicleId),
        driver_id: parseInt(driverId),
        source: source.trim(),
        destination: destination.trim(),
        cargo_weight: parseFloat(cargoWeight),
        planned_distance: parseFloat(plannedDistance),
        status: startStatus,
      } as any);

      showToast(`Trip ${tripNumber.toUpperCase()} successfully registered.`, 'success');
      
      // Reset form
      setTripNumber('');
      setVehicleId('');
      setDriverId('');
      setSource('');
      setDestination('');
      setCargoWeight('');
      setPlannedDistance('');
      setStartStatus('Dispatched');
      setSelectedVehicleObj(null);

      // Reload
      loadResources();
    } catch (err: any) {
      setFormError(err.message || 'Dispatch failed.');
      showToast(err.message || 'Failed to dispatch trip.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Trigger trip completion modal
  const openCompleteModal = (tripId: number, currentOdometer?: number) => {
    setActiveTripToComplete(tripId);
    setTripRevenue('');
    setFinalOdometer(currentOdometer ? currentOdometer.toString() : '');
    setFuelConsumed('');
    setIsCompleteModalOpen(true);
  };

  // Close completed trip
  const handleCompleteTripSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTripToComplete) return;

    if (!tripRevenue || parseFloat(tripRevenue) < 0) {
      showToast('Please enter a valid trip revenue.', 'error');
      return;
    }

    setActionLoading(true);
    try {
      await completeTrip(activeTripToComplete, {
        revenue: parseFloat(tripRevenue),
        final_odometer: finalOdometer ? parseFloat(finalOdometer) : undefined,
        fuel_consumed: fuelConsumed ? parseFloat(fuelConsumed) : undefined,
      });
      showToast('Trip completed. Vehicle and operator released.', 'success');
      setIsCompleteModalOpen(false);
      loadResources();
    } catch (err: any) {
      showToast(err.message || 'Failed to complete trip.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Cancel trip
  const handleCancelTrip = async (tripId: number) => {
    if (!window.confirm('Are you sure you want to cancel this dispatched trip?')) return;

    setActionLoading(true);
    try {
      await cancelTrip(tripId);
      showToast('Trip cancelled. Vehicle and operator restored to Available.', 'success');
      loadResources();
    } catch (err: any) {
      showToast(err.message || 'Failed to cancel trip.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Dispatch a Draft trip
  const handleDispatchDraft = async (tripId: number) => {
    setActionLoading(true);
    try {
      await dispatchDraftTrip(tripId);
      showToast('Draft trip successfully dispatched on active routes.', 'success');
      loadResources();
    } catch (err: any) {
      showToast(err.message || 'Failed to dispatch draft trip.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const isDispatcher = hasRole(['Admin', 'Dispatcher', 'Driver/Dispatcher']);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <Loader2 className="animate-spin text-brand-amber" size={32} />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow">
      {/* Page Title */}
      <div className="mb-8">
        <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest font-heading">Route Scheduling</span>
        <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-0.5 font-heading">Trip Dispatcher</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Left Side: Dispatch Form (Col span 1) */}
        <div className="bg-brand-panel border border-gray-800/60 rounded-xl p-5 shadow-xl">
          <h3 className="font-heading font-bold text-white text-base tracking-wide uppercase mb-4 flex items-center gap-2">
            <Navigation2 size={16} className="text-brand-amber stroke-[2.5]" />
            <span>Dispatch Command</span>
          </h3>

          {isDispatcher ? (
            <form onSubmit={handleDispatch} className="space-y-4">
              {formError && (
                <div className="bg-rose-500/15 border border-rose-500/30 text-rose-400 p-3 rounded-lg text-xs font-semibold flex items-center gap-2">
                  <Info size={14} className="shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Trip Number</label>
                <input
                  type="text"
                  value={tripNumber}
                  onChange={(e) => setTripNumber(e.target.value)}
                  placeholder="e.g. TRIP-1025"
                  className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Vehicle (Eligible)</label>
                  <select
                    value={vehicleId}
                    onChange={(e) => setVehicleId(e.target.value)}
                    className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="">Select Unit</option>
                    {eligibleVehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.registration_number} ({v.type})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Driver (Eligible)</label>
                  <select
                    value={driverId}
                    onChange={(e) => setDriverId(e.target.value)}
                    className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="">Select Operator</option>
                    {eligibleDrivers.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} (SS: {d.safety_score})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {selectedVehicleObj && (
                <div className="bg-[#181E2B]/50 p-2.5 rounded-lg border border-gray-800 text-[10px] text-gray-400 font-semibold space-y-1">
                  <p>Vehicle capacity limits: <span className="text-white">{parseFloat(selectedVehicleObj.max_load_capacity.toString()).toLocaleString()} lbs</span></p>
                  <p>Tank status: <span className="text-brand-teal">{Math.round(selectedVehicleObj.current_fuel_level)}% fuel level</span></p>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Cargo Load Weight (lbs)</label>
                <input
                  type="number"
                  value={cargoWeight}
                  onChange={(e) => setCargoWeight(e.target.value)}
                  placeholder="e.g. 18500"
                  className={`w-full bg-brand-darkBg border ${
                    isWeightOverLimit() ? 'border-rose-500 text-rose-400 focus:border-rose-500' : 'border-gray-800 focus:border-brand-amber'
                  } rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none`}
                />
                {isWeightOverLimit() && (
                  <p className="text-rose-400 text-[10px] font-semibold mt-1 flex items-center gap-1">
                    <AlertTriangle size={10} />
                    <span>Weight exceeds maximum payload capacity.</span>
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Origin</label>
                  <input
                    type="text"
                    value={source}
                    onChange={(e) => setSource(e.target.value)}
                    placeholder="Source hub"
                    className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Destination</label>
                  <input
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="Terminal B"
                    className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Planned Distance (mi)</label>
                  <input
                    type="number"
                    value={plannedDistance}
                    onChange={(e) => setPlannedDistance(e.target.value)}
                    placeholder="e.g. 150"
                    className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Start Status</label>
                  <select
                    value={startStatus}
                    onChange={(e) => setStartStatus(e.target.value as any)}
                    className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="Dispatched">Dispatched (Immediate)</option>
                    <option value="Draft">Draft (Save Only)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={actionLoading || isWeightOverLimit()}
                className="w-full flex items-center justify-center gap-2 bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] py-3 rounded-lg text-xs font-bold font-heading uppercase tracking-wider disabled:opacity-40 shadow-lg shadow-brand-amber/10 mt-2"
              >
                {actionLoading && <Loader2 size={13} className="animate-spin" />}
                <span>Authorize Dispatch</span>
              </button>
            </form>
          ) : (
            <div className="text-center py-6 text-gray-500">
              <Info size={28} className="mx-auto mb-2 opacity-40 text-brand-teal" />
              <p className="text-xs font-semibold uppercase">Read-Only Command View</p>
              <p className="text-[10px] mt-1">Dispatches can only be registered by authorized Dispatcher or Admin operator roles.</p>
            </div>
          )}
        </div>

        {/* Right Side: Active/Past Trips list (Col span 2) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center bg-brand-panel border border-gray-800/60 rounded-xl px-5 py-4 shadow-xl">
            <h3 className="font-heading font-bold text-white text-sm uppercase tracking-wide">Command Dispatch Log</h3>
            <span className="text-[10px] text-gray-500 font-bold uppercase">{trips.length} active/past records</span>
          </div>

          <div className="space-y-4">
            {trips.length > 0 ? (
              trips.map((trip) => {
                const isDispatched = trip.status === 'Dispatched';

                return (
                  <div
                    key={trip.id}
                    className="bg-brand-panel border border-gray-800/50 rounded-xl p-5 shadow-lg relative overflow-hidden transition-all duration-300 hover:border-gray-700"
                  >
                    {/* Header: Number and status */}
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-heading font-bold text-white text-sm">{trip.trip_number}</span>
                          <StatusBadge status={trip.status} />
                        </div>
                        <p className="text-[10px] text-gray-500 font-semibold mt-1">
                          VEHICLE: <span className="text-gray-300">{trip.registration_number} ({trip.vehicle_model})</span> | DRIVER: <span className="text-gray-300">{trip.driver_name}</span>
                        </p>
                      </div>

                      {isDispatcher && isDispatched && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => openCompleteModal(trip.id, trip.vehicle_odometer)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors"
                          >
                            <CheckCircle size={11} />
                            <span>Complete</span>
                          </button>
                          <button
                            onClick={() => handleCancelTrip(trip.id)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors"
                          >
                            <Ban size={11} />
                            <span>Cancel</span>
                          </button>
                        </div>
                      )}

                      {isDispatcher && trip.status === 'Draft' && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleDispatchDraft(trip.id)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-brand-amber/15 hover:bg-brand-amber/30 text-brand-amber border border-brand-amber/20 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors"
                          >
                            <Navigation size={11} />
                            <span>Dispatch Now</span>
                          </button>
                          <button
                            onClick={() => handleCancelTrip(trip.id)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors"
                          >
                            <Ban size={11} />
                            <span>Cancel</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* SVG traveling route visual */}
                    <div className="my-4">
                      <div className="flex justify-between items-center text-[10px] text-gray-400 font-bold mb-1 px-1">
                        <span>{trip.source}</span>
                        <span>{trip.destination}</span>
                      </div>
                      
                      <svg className="w-full h-4" viewBox="0 0 100 10">
                        {/* Background track line */}
                        <line x1="2" y1="5" x2="98" y2="5" stroke="#1F2937" strokeWidth="2" strokeLinecap="round" />
                        
                        {/* Animated traveling dash on active dispatches */}
                        {isDispatched && (
                          <line
                            x1="2"
                            y1="5"
                            x2="98"
                            y2="5"
                            stroke="#2DD4BF"
                            strokeWidth="2"
                            strokeDasharray="4,4"
                            strokeLinecap="round"
                            className="animate-route-travel"
                          />
                        )}

                        {/* Complete lines */}
                        {trip.status === 'Completed' && (
                          <line x1="2" y1="5" x2="98" y2="5" stroke="#10B981" strokeWidth="2" strokeLinecap="round" />
                        )}

                        {/* Cancelled track */}
                        {trip.status === 'Cancelled' && (
                          <line x1="2" y1="5" x2="98" y2="5" stroke="#EF4444" strokeWidth="2" strokeLinecap="round" strokeDasharray="2,2" />
                        )}

                        {/* Endpoints */}
                        <circle cx="2" cy="5" r="3" fill="#F5A623" />
                        <circle cx="98" cy="5" r="3" fill={trip.status === 'Completed' ? '#10B981' : trip.status === 'Cancelled' ? '#EF4444' : '#2DD4BF'} />
                      </svg>
                    </div>

                    {/* Details: Cargo load and earnings */}
                    <div className="flex justify-between items-center text-[10px] text-gray-500 font-semibold pt-3 border-t border-gray-800/40">
                      <span>LOAD LIMIT: {parseFloat(trip.cargo_weight.toString()).toLocaleString()} lbs | DISTANCE: {parseFloat((trip.planned_distance || 0).toString()).toLocaleString()} mi</span>
                      {trip.status === 'Completed' ? (
                        <span className="text-emerald-400 font-bold">REVENUE GENERATED: ${parseFloat(trip.revenue.toString()).toLocaleString()}</span>
                      ) : (
                        <span>CREATED: {new Date(trip.start_date).toLocaleString()}</span>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="bg-brand-panel border border-gray-800/60 rounded-xl p-8 text-center text-gray-500">
                <Navigation size={32} className="mx-auto mb-2 opacity-20" />
                <p className="font-semibold text-gray-400">No trips logged in systems</p>
                <p className="text-xs mt-1">Initiate cargo dispatches using the command panel on the left.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Complete Trip Modal */}
      <Modal
        isOpen={isCompleteModalOpen}
        onClose={() => setIsCompleteModalOpen(false)}
        title="Complete Trip Dispatch"
      >
        <form onSubmit={handleCompleteTripSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Gross Revenue Generated ($)</label>
            <input
              type="number"
              value={tripRevenue}
              onChange={(e) => setTripRevenue(e.target.value)}
              placeholder="e.g. 1500"
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Final Vehicle Odometer (mi)</label>
              <input
                type="number"
                value={finalOdometer}
                onChange={(e) => setFinalOdometer(e.target.value)}
                placeholder="e.g. 24800"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Fuel Consumed (Liters)</label>
              <input
                type="number"
                value={fuelConsumed}
                onChange={(e) => setFuelConsumed(e.target.value)}
                placeholder="e.g. 45.5"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="border-t border-gray-800/80 pt-4 flex justify-end gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsCompleteModalOpen(false)}
              className="px-4 py-2.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-5 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {actionLoading && <Loader2 size={13} className="animate-spin" />}
              <span>Verify Completion</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
export default TripDispatcher;
