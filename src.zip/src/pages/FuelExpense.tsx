import React, { useEffect, useState } from 'react';
import { fetchFuelLogs, createFuelLog, fetchExpenses, createExpense, type FuelLog, type Expense } from '../api/fuelExpenses';
import { fetchVehicles, type Vehicle } from '../api/vehicles';
import { fetchMaintenanceLogs, type MaintenanceLog } from '../api/maintenance';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { DataTable, type Column } from '../components/DataTable';
import { Modal } from '../components/Modal';
import { Loader2, Plus, Info, Fuel, DollarSign, Receipt, Sparkles } from 'lucide-react';

export const FuelExpense: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'fuel' | 'expenses'>('fuel');
  const [fuelLogs, setFuelLogs] = useState<FuelLog[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [maintenance, setMaintenance] = useState<MaintenanceLog[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const { hasRole } = useAuth();
  const { showToast } = useToast();

  // Modals state
  const [isFuelModalOpen, setIsFuelModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);

  // Form Fields
  const [vehicleId, setVehicleId] = useState('');
  const [liters, setLiters] = useState('');
  const [cost, setCost] = useState('');
  const [category, setCategory] = useState<'Tolls' | 'Insurance' | 'Permits' | 'Other'>('Tolls');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [description, setDescription] = useState('');
  const [formError, setFormError] = useState('');

  // Load all logs and aggregates
  const loadData = async () => {
    try {
      const fuels = await fetchFuelLogs();
      setFuelLogs(fuels);

      const exps = await fetchExpenses();
      setExpenses(exps);

      const maints = await fetchMaintenanceLogs();
      setMaintenance(maints);

      const vehs = await fetchVehicles();
      setVehicles(vehs.filter(v => v.status !== 'Retired'));
    } catch (err: any) {
      showToast(err.message || 'Failed to fetch financial telemetry.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openFuelModal = () => {
    setVehicleId('');
    setLiters('');
    setCost('');
    setFormError('');
    setIsFuelModalOpen(true);
  };

  const openExpenseModal = () => {
    setVehicleId('');
    setCategory('Tolls');
    setExpenseAmount('');
    setDescription('');
    setFormError('');
    setIsExpenseModalOpen(true);
  };

  const handleFuelSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!vehicleId) {
      setFormError('Please select a vehicle.');
      return;
    }
    if (!liters || parseFloat(liters) <= 0) {
      setFormError('Please enter a valid liters amount.');
      return;
    }
    if (!cost || parseFloat(cost) < 0) {
      setFormError('Please enter a valid cost.');
      return;
    }

    setActionLoading(true);
    try {
      await createFuelLog({
        vehicle_id: parseInt(vehicleId),
        liters: parseFloat(liters),
        cost: parseFloat(cost),
      });

      showToast('Fuel purchase log created successfully.', 'success');
      setIsFuelModalOpen(false);
      loadData();
    } catch (err: any) {
      setFormError(err.message || 'Logging fuel failed.');
      showToast(err.message || 'Failed to log fuel purchase.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!vehicleId) {
      setFormError('Please select a vehicle.');
      return;
    }
    if (!category) {
      setFormError('Please select an expense category.');
      return;
    }
    if (!expenseAmount || parseFloat(expenseAmount) < 0) {
      setFormError('Please enter a valid expense amount.');
      return;
    }

    setActionLoading(true);
    try {
      await createExpense({
        vehicle_id: parseInt(vehicleId),
        category,
        amount: parseFloat(expenseAmount),
        description: description.trim(),
      });

      showToast('General expense successfully logged.', 'success');
      setIsExpenseModalOpen(false);
      loadData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to log expense.');
      showToast(err.message || 'Failed to record expense.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Financial aggregates calculated from loaded data
  const totalFuelCost = fuelLogs.reduce((acc, log) => acc + parseFloat(log.cost.toString()), 0);
  const totalExpenseCost = expenses.reduce((acc, exp) => acc + parseFloat(exp.amount.toString()), 0);
  const totalMaintCost = maintenance.reduce((acc, log) => acc + parseFloat(log.cost.toString()), 0);
  const grandRunningTotal = totalFuelCost + totalExpenseCost + totalMaintCost;

  const isOperator = hasRole(['Admin', 'Dispatcher', 'Manager', 'Fleet Manager', 'Financial Analyst']);

  // Table Columns
  const fuelColumns: Column<FuelLog>[] = [
    {
      key: 'registration_number',
      label: 'Vehicle',
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-xs text-white bg-gray-800 px-2 py-0.5 rounded">{row.registration_number}</span>,
    },
    { key: 'vehicle_model', label: 'Model', sortable: true },
    {
      key: 'liters',
      label: 'Liters Added',
      sortable: true,
      render: (row) => <span>{parseFloat((row.liters || 0).toString()).toLocaleString()} L</span>,
    },
    {
      key: 'cost',
      label: 'Purchase Cost',
      sortable: true,
      render: (row) => <span className="text-white font-semibold">${parseFloat(row.cost.toString()).toLocaleString()}</span>,
    },
    {
      key: 'logged_at',
      label: 'Date Logged',
      sortable: true,
      render: (row) => <span>{new Date(row.logged_at).toLocaleString()}</span>,
    },
  ];

  const expenseColumns: Column<Expense>[] = [
    {
      key: 'registration_number',
      label: 'Vehicle',
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-xs text-white bg-gray-800 px-2 py-0.5 rounded">{row.registration_number}</span>,
    },
    { key: 'vehicle_model', label: 'Model', sortable: true },
    {
      key: 'category',
      label: 'Category',
      sortable: true,
      render: (row) => (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-brand-teal/10 text-brand-teal border border-brand-teal/20">
          {row.category}
        </span>
      ),
    },
    {
      key: 'amount',
      label: 'Amount Paid',
      sortable: true,
      render: (row) => <span className="text-white font-semibold">${parseFloat(row.amount.toString()).toLocaleString()}</span>,
    },
    { key: 'description', label: 'Notes/Description' },
    {
      key: 'logged_at',
      label: 'Date Logged',
      sortable: true,
      render: (row) => <span>{new Date(row.logged_at).toLocaleString()}</span>,
    },
  ];

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <Loader2 className="animate-spin text-brand-amber" size={32} />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest font-heading">Expense Auditing</span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-0.5">Fuel & Expense Management</h2>
        </div>
        
        {/* Quick action buttons */}
        {isOperator && (
          <div className="flex gap-2">
            <button
              onClick={openFuelModal}
              className="flex items-center gap-2 bg-brand-panel hover:bg-gray-800 text-gray-300 border border-gray-800 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
            >
              <Fuel size={14} className="text-brand-amber" />
              <span>Log Fuel Purchase</span>
            </button>
            <button
              onClick={openExpenseModal}
              className="flex items-center gap-2 bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-brand-amber/10"
            >
              <Receipt size={14} />
              <span>Log Expense Ticket</span>
            </button>
          </div>
        )}
      </div>

      {/* Financial Running cost panel */}
      <div className="bg-[#12161F]/60 border border-gray-800/80 rounded-xl p-5 mb-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_400px_at_right_bottom,rgba(45,212,191,0.04),transparent)] pointer-events-none" />
        
        <div className="flex items-center gap-4">
          <div className="p-3 bg-brand-amber/10 rounded-2xl text-brand-amber border border-brand-amber/20">
            <DollarSign size={24} className="stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-gray-500 tracking-wider">Accumulated Fleet Expenses</span>
            <h3 className="text-3xl font-extrabold font-heading text-white mt-1 leading-none">
              ${grandRunningTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h3>
          </div>
        </div>

        {/* Breakdown items */}
        <div className="flex flex-wrap gap-6 text-xs font-semibold text-gray-400">
          <div>
            <p className="text-[10px] text-gray-500 uppercase tracking-wide">Refuel costs</p>
            <p className="text-sm font-bold text-white mt-1">${totalFuelCost.toLocaleString()}</p>
          </div>
          <div className="border-l border-gray-800/80 pl-6">
            <p className="text-[10px] text-gray-500 uppercase tracking-wide">General expenses</p>
            <p className="text-sm font-bold text-white mt-1">${totalExpenseCost.toLocaleString()}</p>
          </div>
          <div className="border-l border-gray-800/80 pl-6">
            <p className="text-[10px] text-gray-500 uppercase tracking-wide">Maintenance logs</p>
            <p className="text-sm font-bold text-white mt-1">${totalMaintCost.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Tabs list */}
      <div className="flex border-b border-gray-800 mb-6">
        <button
          onClick={() => setActiveTab('fuel')}
          className={`px-6 py-3 font-heading font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeTab === 'fuel'
              ? 'border-brand-amber text-white'
              : 'border-transparent text-gray-500 hover:text-gray-300'
          }`}
        >
          Fuel Telemetry Logs
        </button>
        <button
          onClick={() => setActiveTab('expenses')}
          className={`px-6 py-3 font-heading font-bold text-xs uppercase tracking-wider border-b-2 transition-all ${
            activeTab === 'expenses'
              ? 'border-brand-amber text-white'
              : 'border-transparent text-gray-500 hover:text-gray-300'
          }`}
        >
          General Operating Expenses
        </button>
      </div>

      {/* Tables based on tabs */}
      {activeTab === 'fuel' ? (
        <DataTable
          columns={fuelColumns}
          data={fuelLogs}
          searchKey="registration_number"
          searchPlaceholder="Search by vehicle registration..."
        />
      ) : (
        <DataTable
          columns={expenseColumns}
          data={expenses}
          searchKey="registration_number"
          searchPlaceholder="Search by vehicle registration..."
          filterOptions={[
            {
              key: 'category',
              label: 'Filter Category',
              options: [
                { label: 'Tolls', value: 'Tolls' },
                { label: 'Insurance', value: 'Insurance' },
                { label: 'Permits', value: 'Permits' },
                { label: 'Other', value: 'Other' },
              ],
            },
          ]}
        />
      )}

      {/* Fuel purchase Modal */}
      <Modal
        isOpen={isFuelModalOpen}
        onClose={() => setIsFuelModalOpen(false)}
        title="Log Refuel Purchase"
      >
        <form onSubmit={handleFuelSubmit} className="space-y-4">
          {formError && (
            <div className="bg-rose-500/15 border border-rose-500/30 text-rose-400 p-3 rounded-lg text-xs font-semibold flex items-center gap-2">
              <Info size={14} className="shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Select Refueled Vehicle</label>
            <select
              value={vehicleId}
              onChange={(e) => setVehicleId(e.target.value)}
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
            >
              <option value="">Choose Asset</option>
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.registration_number} - {v.model}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Liters Added</label>
              <input
                type="number"
                value={liters}
                onChange={(e) => setLiters(e.target.value)}
                placeholder="e.g. 210.5"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Purchase Cost ($)</label>
              <input
                type="number"
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                placeholder="e.g. 185.50"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="border-t border-gray-800/80 pt-4 flex justify-end gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsFuelModalOpen(false)}
              className="px-4 py-2.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-5 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {actionLoading && <Loader2 size={13} className="animate-spin" />}
              <span>Verify Log</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* General Expense Modal */}
      <Modal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        title="Log General Expense Receipt"
      >
        <form onSubmit={handleExpenseSubmit} className="space-y-4">
          {formError && (
            <div className="bg-rose-500/15 border border-rose-500/30 text-rose-400 p-3 rounded-lg text-xs font-semibold flex items-center gap-2">
              <Info size={14} className="shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Select Vehicle</label>
            <select
              value={vehicleId}
              onChange={(e) => setVehicleId(e.target.value)}
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
            >
              <option value="">Choose Asset</option>
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.registration_number} - {v.model}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Expense Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="Tolls">Highway Tolls</option>
                <option value="Insurance">Asset Insurance</option>
                <option value="Permits">Border Permits</option>
                <option value="Other">Other Expenses</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Expense Amount Paid ($)</label>
              <input
                type="number"
                value={expenseAmount}
                onChange={(e) => setExpenseAmount(e.target.value)}
                placeholder="e.g. 75"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Description/Notes</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. state line permit fees"
              className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
            />
          </div>

          <div className="border-t border-gray-800/80 pt-4 flex justify-end gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsExpenseModalOpen(false)}
              className="px-4 py-2.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-5 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {actionLoading && <Loader2 size={13} className="animate-spin" />}
              <span>Verify Log</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
export default FuelExpense;
