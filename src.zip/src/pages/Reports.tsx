import React, { useEffect, useState } from 'react';
import { fetchReportsData, downloadReportCSV, type ReportsData } from '../api/reports';
import { useToast } from '../context/ToastContext';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Loader2, Download, Table, BarChart3, TrendingUp, DollarSign } from 'lucide-react';


export const Reports: React.FC = () => {
  const [data, setData] = useState<ReportsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState<string | null>(null);
  const [activeReportTab, setActiveReportTab] = useState<'roi' | 'costs' | 'fuel' | 'utilization'>('roi');
  const { showToast } = useToast();

  const loadReports = async () => {
    try {
      const reports = await fetchReportsData();
      setData(reports);
    } catch (err: any) {
      showToast(err.message || 'Failed to retrieve analytics databases.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, []);

  const handleExportCSV = async (type: 'roi' | 'costs' | 'fuel' | 'utilization') => {
    setExporting(type);
    try {
      await downloadReportCSV(type);
      showToast(`Exported ${type.toUpperCase()} report as CSV file.`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Export failed.', 'error');
    } finally {
      setExporting(null);
    }
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="animate-spin text-brand-amber" size={32} />
          <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider">Compiling Fleet Intelligence...</p>
        </div>
      </div>
    );
  }

  const reports = data || { roi: [], costs: [], fuel: [], utilization: [], monthlyRevenue: [] };

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow">
      {/* Header */}
      <div className="mb-8">
        <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest font-heading">Business Intelligence</span>
        <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-0.5">Reports & Analytics</h2>
      </div>

      {/* Top Section: Monthly Revenue Chart (Teal Accent) */}
      <div className="bg-brand-panel border border-gray-800/60 rounded-xl p-5 shadow-xl mb-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_300px_at_50%_-100px,rgba(45,212,191,0.02),transparent)] pointer-events-none" />
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="font-heading font-bold text-white text-base tracking-wide uppercase flex items-center gap-2">
              <TrendingUp size={16} className="text-brand-teal" />
              <span>Revenue Growth</span>
            </h3>
            <p className="text-[10px] text-gray-500 font-semibold uppercase">Operational revenue over the past 6 months</p>
          </div>
        </div>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={reports.monthlyRevenue}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
              <XAxis dataKey="month" stroke="#6B7280" fontSize={11} tickLine={false} />
              <YAxis 
                stroke="#6B7280" 
                fontSize={11} 
                tickLine={false} 
                tickFormatter={(value) => `$${value}`}
              />
              <Tooltip
                cursor={{ fill: 'rgba(255, 255, 255, 0.02)' }}
                contentStyle={{
                  backgroundColor: '#12161F',
                  borderColor: '#1F2937',
                  color: '#E2E8F0',
                  borderRadius: '8px',
                  fontSize: '11px',
                }}
                formatter={(value) => [`$${value}`, 'Revenue']}
              />
              <Bar dataKey="revenue" fill="#2DD4BF" radius={[4, 4, 0, 0]} maxBarSize={45} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Reports Grid Tabs */}
      <div className="flex border-b border-gray-800 mb-6">
        <button
          onClick={() => setActiveReportTab('roi')}
          className={`px-5 py-3 font-heading font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
            activeReportTab === 'roi' ? 'border-brand-amber text-white' : 'border-transparent text-gray-500 hover:text-gray-300'
          }`}
        >
          <TrendingUp size={14} />
          <span>Vehicle ROI</span>
        </button>
        <button
          onClick={() => setActiveReportTab('costs')}
          className={`px-5 py-3 font-heading font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
            activeReportTab === 'costs' ? 'border-brand-amber text-white' : 'border-transparent text-gray-500 hover:text-gray-300'
          }`}
        >
          <DollarSign size={14} />
          <span>Operational Costs</span>
        </button>
        <button
          onClick={() => setActiveReportTab('fuel')}
          className={`px-5 py-3 font-heading font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
            activeReportTab === 'fuel' ? 'border-brand-amber text-white' : 'border-transparent text-gray-500 hover:text-gray-300'
          }`}
        >
          <Table size={14} />
          <span>Fuel Efficiency</span>
        </button>
        <button
          onClick={() => setActiveReportTab('utilization')}
          className={`px-5 py-3 font-heading font-bold text-xs uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 ${
            activeReportTab === 'utilization' ? 'border-brand-amber text-white' : 'border-transparent text-gray-500 hover:text-gray-300'
          }`}
        >
          <BarChart3 size={14} />
          <span>Fleet Utilization</span>
        </button>
      </div>

      {/* Report Panel */}
      <div className="bg-brand-panel border border-gray-800/60 rounded-xl p-5 shadow-xl">
        {/* Title / Action bar */}
        <div className="flex justify-between items-center mb-5">
          <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
            {activeReportTab === 'roi' && 'Fleet Return On Investment Analysis'}
            {activeReportTab === 'costs' && 'Asset Operational Cost Breakdowns'}
            {activeReportTab === 'fuel' && 'Fuel Purchase Efficiency Reports'}
            {activeReportTab === 'utilization' && 'Freight Utilization Telemeter Logs'}
          </h4>
          <button
            onClick={() => handleExportCSV(activeReportTab)}
            disabled={exporting !== null}
            className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700/50 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all"
          >
            {exporting === activeReportTab ? (
              <Loader2 size={12} className="animate-spin text-brand-amber" />
            ) : (
              <Download size={12} />
            )}
            <span>Export CSV</span>
          </button>
        </div>

        {/* Dynamic Report Table */}
        <div className="overflow-x-auto">
          {activeReportTab === 'roi' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-800 text-gray-500 uppercase font-semibold">
                  <th className="pb-3 pl-2">Vehicle</th>
                  <th className="pb-3">Model</th>
                  <th className="pb-3 text-right">Acquisition Cost</th>
                  <th className="pb-3 text-right">Total Revenue</th>
                  <th className="pb-3 text-right">Total Operating Costs</th>
                  <th className="pb-3 text-right">Net Profit</th>
                  <th className="pb-3 text-right pr-2">ROI %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/40 text-gray-300">
                {reports.roi.map((row: any) => {
                  const totalCosts = parseFloat(row.total_maintenance) + parseFloat(row.total_fuel) + parseFloat(row.total_expenses);
                  const isPositive = parseFloat(row.net_profit) >= 0;
                  return (
                    <tr key={row.id} className="hover:bg-gray-800/10">
                      <td className="py-3.5 pl-2 font-mono font-bold text-white">{row.registration_number}</td>
                      <td className="py-3.5">{row.model}</td>
                      <td className="py-3.5 text-right">${parseFloat(row.acquisition_cost).toLocaleString()}</td>
                      <td className="py-3.5 text-right text-emerald-400 font-semibold">${parseFloat(row.total_revenue).toLocaleString()}</td>
                      <td className="py-3.5 text-right text-rose-400">${totalCosts.toLocaleString()}</td>
                      <td className={`py-3.5 text-right font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                        ${parseFloat(row.net_profit).toLocaleString()}
                      </td>
                      <td className={`py-3.5 text-right pr-2 font-extrabold ${parseFloat(row.roi_percentage) >= 0 ? 'text-brand-teal' : 'text-rose-400'}`}>
                        {row.roi_percentage}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {activeReportTab === 'costs' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-800 text-gray-500 uppercase font-semibold">
                  <th className="pb-3 pl-2">Vehicle</th>
                  <th className="pb-3">Model</th>
                  <th className="pb-3 text-right">Fuel Costs</th>
                  <th className="pb-3 text-right">Maintenance Costs</th>
                  <th className="pb-3 text-right">Other Expenses</th>
                  <th className="pb-3 text-right pr-2">Total Operational Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/40 text-gray-300">
                {reports.costs.map((row: any, rIdx) => (
                  <tr key={rIdx} className="hover:bg-gray-800/10">
                    <td className="py-3.5 pl-2 font-mono font-bold text-white">{row.registration_number}</td>
                    <td className="py-3.5">{row.model}</td>
                    <td className="py-3.5 text-right">${parseFloat(row.fuel_cost).toLocaleString()}</td>
                    <td className="py-3.5 text-right">${parseFloat(row.maintenance_cost).toLocaleString()}</td>
                    <td className="py-3.5 text-right">${parseFloat(row.other_expenses).toLocaleString()}</td>
                    <td className="py-3.5 text-right pr-2 font-bold text-white">${parseFloat(row.total_operational_cost).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'fuel' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-800 text-gray-500 uppercase font-semibold">
                  <th className="pb-3 pl-2">Vehicle</th>
                  <th className="pb-3">Model</th>
                  <th className="pb-3 text-right">Total Gallons Added</th>
                  <th className="pb-3 text-right">Total Fuel Spent</th>
                  <th className="pb-3 text-right">Refuel Occurrences</th>
                  <th className="pb-3 text-right pr-2">Average Price/Gal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/40 text-gray-300">
                {reports.fuel.map((row: any, rIdx) => (
                  <tr key={rIdx} className="hover:bg-gray-800/10">
                    <td className="py-3.5 pl-2 font-mono font-bold text-white">{row.registration_number}</td>
                    <td className="py-3.5">{row.model}</td>
                    <td className="py-3.5 text-right">{parseFloat(row.total_gallons).toLocaleString()} gal</td>
                    <td className="py-3.5 text-right font-semibold text-white">${parseFloat(row.total_fuel_spent).toLocaleString()}</td>
                    <td className="py-3.5 text-right">{row.refuels_count} refuels</td>
                    <td className="py-3.5 text-right pr-2 text-brand-teal font-semibold">${parseFloat(row.average_price_per_gallon).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'utilization' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-800 text-gray-500 uppercase font-semibold">
                  <th className="pb-3 pl-2">Vehicle</th>
                  <th className="pb-3">Model</th>
                  <th className="pb-3 text-right">Trips Completed</th>
                  <th className="pb-3 text-right">Total Weight Moved</th>
                  <th className="pb-3 text-right pr-2">Average Cargo Weight</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/40 text-gray-300">
                {reports.utilization.map((row: any, rIdx) => (
                  <tr key={rIdx} className="hover:bg-gray-800/10">
                    <td className="py-3.5 pl-2 font-mono font-bold text-white">{row.registration_number}</td>
                    <td className="py-3.5">{row.model}</td>
                    <td className="py-3.5 text-right">{row.trips_completed} trips</td>
                    <td className="py-3.5 text-right">{parseFloat(row.total_weight_moved).toLocaleString()} lbs</td>
                    <td className="py-3.5 text-right pr-2 text-brand-teal font-semibold">{parseFloat(row.average_cargo_weight).toLocaleString()} lbs</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
export default Reports;
