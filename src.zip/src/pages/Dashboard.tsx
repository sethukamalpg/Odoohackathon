import React, { useEffect, useState } from 'react';
import { fetchDashboardKPIs, type DashboardKPIs } from '../api/reports';
import { KPICard } from '../components/KPICard';
import { StatusBadge } from '../components/StatusBadge';
import { useToast } from '../context/ToastContext';
import { Link } from 'react-router-dom';
import { FleetStatusChart3D } from '../components/FleetStatusChart3D';
import { useAuth } from '../context/AuthContext';
import { Truck, Navigation, DollarSign, BarChart2, Loader2, ArrowRight, Search, Bell } from 'lucide-react';


export const Dashboard: React.FC = () => {
  const [data, setData] = useState<DashboardKPIs | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const { user } = useAuth();
  const { showToast } = useToast();

  // Filters State
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterRegion, setFilterRegion] = useState('');

  useEffect(() => {
    const loadDashboard = async () => {
      try {
        setRefreshing(true);
        const result = await fetchDashboardKPIs({
          vehicleType: filterType,
          status: filterStatus,
          region: filterRegion
        });
        setData(result);
      } catch (err: any) {
        showToast(err.message || 'Failed to fetch dashboard intelligence.', 'error');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    };

    loadDashboard();
  }, [filterType, filterStatus, filterRegion, showToast]);

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="animate-spin text-brand-amber" size={32} />
          <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider">Loading Fleet Command...</p>
        </div>
      </div>
    );
  }

  const kpis = data?.kpis || {
    totalVehicles: 0,
    activeVehicles: 0,
    availableVehicles: 0,
    vehiclesInMaintenance: 0,
    activeTrips: 0,
    pendingTrips: 0,
    driversOnDuty: 0,
    totalMaintenanceCost: 0,
    totalRevenue: 0,
    utilizationRate: 0,
  };

  const chartData = data?.fleetDistribution || [];

  // Theme chart colors for legend
  const COLORS = {
    'Available': '#2DD4BF',  // Teal
    'On Trip': '#38BDF8',     // Sky Blue
    'In Shop': '#F5A623',     // Amber
    'Retired': '#FB7185',     // Rose Red
  };

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow flex flex-col">
      {/* Top Header Bar matching Reference 1 */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 mb-6 border-b border-gray-800/40 relative z-20">
        {/* Left Search Bar Input */}
        <div className="relative w-full md:max-w-xs">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-gray-500 pointer-events-none">
            <Search size={16} />
          </span>
          <input
            type="text"
            placeholder="Search telemetry..."
            className="w-full bg-[#121620] border border-gray-800/80 focus:border-brand-amber rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none transition-all"
          />
        </div>

        {/* Right Section: System stats, alerts, profile */}
        <div className="flex items-center justify-between md:justify-end w-full md:w-auto gap-5">
          <div className="text-right hidden sm:block">
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Telemetry Live</p>
            <p className="text-xs font-bold text-gray-300 font-heading mt-0.5">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
            </p>
          </div>

          <div className="flex items-center gap-3.5 ml-auto sm:ml-0">
            {/* Notification alert bell */}
            <button className="p-2.5 bg-[#121620] hover:bg-gray-800 border border-gray-800/60 rounded-xl text-gray-400 hover:text-white transition-all relative">
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-brand-amber rounded-full" />
              <Bell size={15} />
            </button>

            {/* Profile widget matching Reference 1 */}
            <div className="flex items-center gap-3 bg-[#121620] border border-gray-800/60 rounded-xl px-3 py-1.5">
              <div className="w-6 h-6 rounded-full bg-brand-amber/15 text-brand-amber flex items-center justify-center text-xs font-bold font-heading border border-brand-amber/20">
                {user?.name.charAt(0).toUpperCase()}
              </div>
              <div className="text-left hidden xs:block">
                <p className="text-xs font-semibold text-white leading-none">{user?.name}</p>
                <span className="text-[9px] uppercase font-bold text-brand-teal tracking-wider mt-0.5 block">{user?.role}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome Title & Dynamic Filters Row */}
      <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-widest font-heading">
              {refreshing ? 'Updating Intelligence...' : 'Active Command Stream'}
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-1">Operations Control</h2>
        </div>
        
        {/* Spec Filters: Vehicle Type, Status, Region */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-[#121620] border border-gray-800/80 rounded-xl px-3 py-2 text-xs text-gray-300 focus:border-brand-amber focus:outline-none transition-all cursor-pointer min-w-[120px]"
          >
            <option value="">All Types</option>
            <option value="Semi">Semi</option>
            <option value="Flatbed">Flatbed</option>
            <option value="Box Truck">Box Truck</option>
            <option value="Van">Van</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-[#121620] border border-gray-800/80 rounded-xl px-3 py-2 text-xs text-gray-300 focus:border-brand-amber focus:outline-none transition-all cursor-pointer min-w-[120px]"
          >
            <option value="">All Statuses</option>
            <option value="Available">Available</option>
            <option value="On Trip">On Trip</option>
            <option value="In Shop">In Shop</option>
            <option value="Retired">Retired</option>
          </select>

          <select
            value={filterRegion}
            onChange={(e) => setFilterRegion(e.target.value)}
            className="bg-[#121620] border border-gray-800/80 rounded-xl px-3 py-2 text-xs text-gray-300 focus:border-brand-amber focus:outline-none transition-all cursor-pointer min-w-[120px]"
          >
            <option value="">All Regions</option>
            <option value="North">North</option>
            <option value="South">South</option>
            <option value="East">East</option>
            <option value="West">West</option>
          </select>
        </div>
      </div>

      {/* KPI Cards Row (First Card highlighted solid amber matching Reference 1) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-6">
        <KPICard
          title="Active / Fleet Vehicles"
          value={`${kpis.activeVehicles} / ${kpis.totalVehicles}`}
          icon={Truck}
          subtitle={`${kpis.availableVehicles} Available • ${kpis.vehiclesInMaintenance} In Shop`}
          accentColor="amber"
          highlighted={true}
        />
        <KPICard
          title="Active / Pending Trips"
          value={`${kpis.activeTrips} / ${kpis.pendingTrips}`}
          icon={Navigation}
          subtitle="Trips dispatched / drafted"
          accentColor="teal"
        />
        <KPICard
          title="Drivers On Duty"
          value={kpis.driversOnDuty}
          icon={DollarSign}
          subtitle="Drivers actively driving"
          accentColor="teal"
        />
        <KPICard
          title="Fleet utilization"
          value={kpis.utilizationRate}
          icon={BarChart2}
          suffix="%"
          subtitle="Non-retired units on trip"
          accentColor="amber"
        />
      </div>

      {/* Main Grid: Left = Recent Trips, Right = Fleet status distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Trips List (Col span 2) */}
        <div className="lg:col-span-2 bg-brand-panel border border-gray-800/60 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-5">
              <h3 className="font-heading font-bold text-white text-base tracking-wide uppercase">Recent Trip Logs</h3>
              <Link
                to="/dispatch"
                className="flex items-center gap-1 text-xs font-bold text-brand-amber hover:text-brand-amber/80 transition-colors"
              >
                <span>Dispatch Manager</span>
                <ArrowRight size={14} />
              </Link>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-gray-800 text-gray-500 uppercase font-semibold">
                    <th className="pb-3.5 pl-2">Trip Ref</th>
                    <th className="pb-3.5">Vehicle</th>
                    <th className="pb-3.5">Driver</th>
                    <th className="pb-3.5">Route</th>
                    <th className="pb-3.5">Cargo Wt</th>
                    <th className="pb-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800/40 text-gray-300">
                  {data && data.recentTrips.length > 0 ? (
                    data.recentTrips.map((trip) => (
                      <tr key={trip.id} className="hover:bg-gray-800/10">
                        <td className="py-3.5 pl-2 font-semibold text-white">{trip.trip_number}</td>
                        <td className="py-3.5">{trip.registration_number} <span className="text-gray-500">({trip.vehicle_model})</span></td>
                        <td className="py-3.5">{trip.driver_name}</td>
                        <td className="py-3.5">{trip.source} → {trip.destination}</td>
                        <td className="py-3.5">{parseFloat(trip.cargo_weight).toLocaleString()} lbs</td>
                        <td className="py-3.5">
                          <StatusBadge status={trip.status} />
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-gray-500">
                        No recent trip dispatches recorded.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Fleet Distribution Chart (Col span 1) */}
        <div className="bg-brand-panel border border-gray-800/60 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-heading font-bold text-white text-base tracking-wide uppercase mb-1">Fleet Distribution</h3>
            <p className="text-[10px] text-gray-500 font-semibold mb-4 uppercase">Status breakdown of all registered assets</p>
            
            <div className="h-64 relative flex items-center justify-center">
              <FleetStatusChart3D distribution={chartData} />
            </div>
          </div>

          {/* Custom Legends list */}
          <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-800/40 text-xs font-semibold">
            {chartData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div 
                  className="w-2.5 h-2.5 rounded-full shrink-0" 
                  style={{ backgroundColor: COLORS[item.name as keyof typeof COLORS] }}
                />
                <span className="text-gray-400">{item.name}:</span>
                <span className="text-white ml-auto">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
export default Dashboard;
