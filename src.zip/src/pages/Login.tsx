import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, ArrowRight, Loader2 } from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { InteractiveGlobe3D } from '../components/InteractiveGlobe3D';

export const Login: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(false);

  // Field validation states
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const handleValidation = () => {
    let isValid = true;
    setEmailError('');
    setPasswordError('');

    if (!email) {
      setEmailError('Please enter your email address.');
      isValid = false;
    } else if (!emailRegex.test(email)) {
      setEmailError('Please enter a valid email address.');
      isValid = false;
    }

    if (!password) {
      setPasswordError('Please enter your password.');
      isValid = false;
    } else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters.');
      isValid = false;
    }

    if (!isValid) {
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }

    return isValid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!handleValidation()) return;

    setLoading(true);
    try {
      await login(email, password);
      showToast('Logged in successfully. Welcome to Fleet Command.', 'success');
      navigate('/dashboard');
    } catch (err: any) {
      showToast(err.message || 'Incorrect email or password.', 'error');
      setShake(true);
      setTimeout(() => setShake(false), 500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-brand-darkBg text-gray-200">
      {/* Left Panel: Branding & Mission Glow */}
      <div className="hidden lg:flex lg:w-1/2 bg-[#080B10] relative overflow-hidden flex-col justify-between p-12 border-r border-gray-800/40">
        
        {/* Interactive 3D Globe Component in the Background */}
        <div className="absolute inset-0 z-0">
          <InteractiveGlobe3D />
        </div>

        {/* Top Header */}
        <div className="flex items-center gap-3 relative z-10">
          <div className="bg-brand-amber/10 p-2.5 rounded-xl text-brand-amber border border-brand-amber/20 backdrop-blur-md">
            <ShieldCheck size={28} className="stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white font-heading tracking-wide">TransitOps</h1>
            <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest leading-none block mt-0.5">Fleet Command Center</span>
          </div>
        </div>

        {/* Center content - overlay with solid background backdrops for readable overlays */}
        <div className="max-w-md my-auto relative z-10 bg-brand-darkBg/60 p-6 rounded-2xl border border-gray-800/40 backdrop-blur-md">
          <h2 className="text-3xl font-extrabold text-white tracking-tight font-heading leading-tight mb-4">
            Mission Control For Live Fleets.
          </h2>
          <p className="text-gray-400 leading-relaxed font-medium text-xs">
            Monitor routes, track cargo weight constraints, schedule maintenance tickets, and analyze operational ROI in real-time.
          </p>

          <div className="mt-6 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-brand-teal animate-pulse" />
              <span className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Live operational telemetry status tracking</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-brand-amber" />
              <span className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Role-based dispatch approvals and locks</span>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="relative z-10 flex justify-between items-center text-[10px] text-gray-500 font-bold uppercase border-t border-gray-800/40 pt-6 backdrop-blur-sm">
          <span>TransitOps command v1.0.0</span>
          <span>© 2026 Fleet Operations</span>
        </div>
      </div>

      {/* Right Panel: Login form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 sm:p-12">
        <div className={`w-full max-w-md space-y-8 transition-transform duration-500 ${shake ? 'animate-shake' : ''}`}>
          {/* Header */}
          <div>
            <div className="lg:hidden flex items-center gap-3 mb-6">
              <div className="bg-brand-amber/10 p-2 rounded-xl text-brand-amber border border-brand-amber/20">
                <ShieldCheck size={24} className="stroke-[2.5]" />
              </div>
              <h1 className="text-lg font-bold text-white font-heading">TransitOps</h1>
            </div>
            <h2 className="text-3xl font-extrabold text-white tracking-tight font-heading">Sign In Command</h2>
            <p className="text-gray-400 mt-2 text-sm">
              Enter your credentials below to establish connection with fleet databases.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                Database Access Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setEmailError('');
                }}
                placeholder="operator@transitops.com"
                className={`w-full bg-brand-panel border ${
                  emailError ? 'border-rose-500 focus:border-rose-500' : 'border-gray-800 focus:border-brand-amber'
                } rounded-xl px-4 py-3 text-sm text-white placeholder-gray-600 focus:outline-none transition-colors`}
              />
              {emailError && (
                <p className="text-rose-400 text-xs font-semibold mt-1.5">{emailError}</p>
              )}
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                Secret Access Keys
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setPasswordError('');
                }}
                placeholder="••••••••"
                className={`w-full bg-brand-panel border ${
                  passwordError ? 'border-rose-500 focus:border-rose-500' : 'border-gray-800 focus:border-brand-amber'
                } rounded-xl px-4 py-3 text-sm text-white placeholder-gray-600 focus:outline-none transition-colors`}
              />
              {passwordError && (
                <p className="text-rose-400 text-xs font-semibold mt-1.5">{passwordError}</p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] font-bold py-3.5 px-4 rounded-xl text-sm transition-all focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed group shadow-lg shadow-brand-amber/10"
            >
              {loading ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <>
                  <span>Initialize Connection</span>
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-6px); }
          20%, 40%, 60%, 80% { transform: translateX(6px); }
        }
        .animate-shake {
          animation: shake 0.4s ease-in-out;
        }
      `}</style>
    </div>
  );
};
export default Login;
