import React, { useEffect, useState } from 'react';
import { fetchVehicles, createVehicle, updateVehicle, deleteVehicle, type Vehicle } from '../api/vehicles';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { DataTable, type Column } from '../components/DataTable';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Plus, Edit2, Trash2, Loader2, Info } from 'lucide-react';

export const VehicleRegistry: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const { hasRole } = useAuth();
  const { showToast } = useToast();

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);

  // Form Fields
  const [regNumber, setRegNumber] = useState('');
  const [model, setModel] = useState('');
  const [type, setType] = useState('Semi');
  const [status, setStatus] = useState<'Available' | 'On Trip' | 'In Shop' | 'Retired'>('Available');
  const [loadCapacity, setLoadCapacity] = useState('');
  const [acqCost, setAcqCost] = useState('');
  const [odometer, setOdometer] = useState('0');
  const [region, setRegion] = useState<'North' | 'South' | 'East' | 'West'>('North');
  const [formError, setFormError] = useState('');

  // Load Vehicles
  const loadVehicles = async () => {
    try {
      const data = await fetchVehicles();
      setVehicles(data);
    } catch (err: any) {
      showToast(err.message || 'Failed to fetch vehicles list.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
  }, []);

  const openAddModal = () => {
    setSelectedVehicle(null);
    setRegNumber('');
    setModel('');
    setType('Semi');
    setStatus('Available');
    setLoadCapacity('');
    setAcqCost('');
    setOdometer('0');
    setRegion('North');
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setRegNumber(vehicle.registration_number);
    setModel(vehicle.model);
    setType(vehicle.type);
    setStatus(vehicle.status);
    setLoadCapacity(vehicle.max_load_capacity.toString());
    setAcqCost(vehicle.acquisition_cost.toString());
    setOdometer(vehicle.odometer ? vehicle.odometer.toString() : '0');
    setRegion(vehicle.region || 'North');
    setFormError('');
    setIsModalOpen(true);
  };

  const handleFormValidation = () => {
    if (!regNumber.trim()) {
      setFormError('Please enter a vehicle registration number.');
      return false;
    }
    if (!model.trim()) {
      setFormError('Please enter the vehicle model.');
      return false;
    }
    if (!loadCapacity || parseFloat(loadCapacity) <= 0) {
      setFormError('Please enter a valid max load capacity greater than 0.');
      return false;
    }
    if (!acqCost || parseFloat(acqCost) < 0) {
      setFormError('Please enter a valid acquisition cost.');
      return false;
    }
    if (odometer === undefined || parseFloat(odometer) < 0) {
      setFormError('Odometer reading cannot be negative.');
      return false;
    }
    setFormError('');
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!handleFormValidation()) return;

    setActionLoading(true);
    const vehicleData = {
      registration_number: regNumber.trim().toUpperCase(),
      model: model.trim(),
      type,
      status,
      max_load_capacity: parseFloat(loadCapacity),
      acquisition_cost: parseFloat(acqCost),
      odometer: parseFloat(odometer),
      region,
    };

    try {
      if (selectedVehicle) {
        // Edit Action
        await updateVehicle(selectedVehicle.id, vehicleData);
        showToast('Vehicle configuration updated successfully.', 'success');
      } else {
        // Create Action
        await createVehicle(vehicleData);
        showToast('New vehicle registered in fleet database.', 'success');
      }
      setIsModalOpen(false);
      loadVehicles();
    } catch (err: any) {
      setFormError(err.message || 'Operation failed. Verify parameters.');
      showToast(err.message || 'Failed to submit vehicle details.', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Are you sure you want to retire and remove this vehicle from the database?')) return;
    
    try {
      await deleteVehicle(id);
      showToast('Vehicle deleted successfully from registry.', 'success');
      loadVehicles();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete vehicle.', 'error');
    }
  };

  // RBAC checks
  const canEdit = hasRole(['Admin', 'Manager', 'Fleet Manager']);
  const canDelete = hasRole(['Admin']);

  // Table Columns
  const columns: Column<Vehicle>[] = [
    {
      key: 'registration_number',
      label: 'Reg Number',
      sortable: true,
      render: (row) => <span className="font-mono font-bold text-white text-xs bg-gray-800/60 px-2 py-1 rounded">{row.registration_number}</span>,
    },
    { key: 'model', label: 'Model', sortable: true },
    { key: 'type', label: 'Type', sortable: true },
    { key: 'region', label: 'Region', sortable: true },
    {
      key: 'odometer',
      label: 'Odometer',
      sortable: true,
      render: (row) => <span>{parseFloat(row.odometer?.toString() || '0').toLocaleString()} mi</span>,
    },
    {
      key: 'max_load_capacity',
      label: 'Load Limit',
      sortable: true,
      render: (row) => <span>{parseFloat(row.max_load_capacity.toString()).toLocaleString()} lbs</span>,
    },
    {
      key: 'acquisition_cost',
      label: 'Acq Cost',
      sortable: true,
      render: (row) => <span>${parseFloat(row.acquisition_cost.toString()).toLocaleString()}</span>,
    },
    {
      key: 'current_fuel_level',
      label: 'Fuel Tank',
      sortable: true,
      render: (row) => (
        <div className="flex items-center gap-2">
          <div className="w-12 bg-gray-800 rounded-full h-1.5 overflow-hidden">
            <div 
              className={`h-full rounded-full ${row.current_fuel_level > 30 ? 'bg-brand-teal' : 'bg-rose-500'}`} 
              style={{ width: `${row.current_fuel_level}%` }}
            />
          </div>
          <span className="text-xs">{Math.round(row.current_fuel_level)}%</span>
        </div>
      ),
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (row) => <StatusBadge status={row.status} />,
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (row) => (
        <div className="flex gap-2.5">
          {canEdit && (
            <button
              onClick={() => openEditModal(row)}
              className="text-gray-400 hover:text-brand-amber transition-colors p-1"
              title="Edit Configuration"
            >
              <Edit2 size={14} />
            </button>
          )}
          {canDelete && (
            <button
              onClick={() => handleDelete(row.id)}
              className="text-gray-400 hover:text-rose-500 transition-colors p-1"
              title="Remove Unit"
            >
              <Trash2 size={14} />
            </button>
          )}
          {!canEdit && <span className="text-xs text-gray-600 font-semibold uppercase">Read-only</span>}
        </div>
      ),
    },
  ];

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-brand-darkBg h-screen">
        <Loader2 className="animate-spin text-brand-amber" size={32} />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-brand-darkBg min-h-screen overflow-y-auto p-6 md:p-8 amber-glow">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest font-heading">Asset Management</span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight font-heading mt-0.5">Vehicle Registry</h2>
        </div>
        {canEdit && (
          <button
            onClick={openAddModal}
            className="flex items-center gap-2 bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-4 py-2.5 rounded-xl text-xs font-bold font-heading uppercase tracking-wider shadow-lg shadow-brand-amber/10 transition-all hover:scale-[1.02]"
          >
            <Plus size={15} />
            <span>Add Vehicle</span>
          </button>
        )}
      </div>

      {/* Main Table */}
      <DataTable
        columns={columns}
        data={vehicles}
        searchKey="registration_number"
        searchPlaceholder="Filter by registration number..."
        filterOptions={[
          {
            key: 'type',
            label: 'Filter Type',
            options: [
              { label: 'Semi Truck', value: 'Semi' },
              { label: 'Box Truck', value: 'Truck' },
              { label: 'Cargo Van', value: 'Van' },
            ],
          },
          {
            key: 'status',
            label: 'Filter Status',
            options: [
              { label: 'Available', value: 'Available' },
              { label: 'On Trip', value: 'On Trip' },
              { label: 'In Shop', value: 'In Shop' },
              { label: 'Retired', value: 'Retired' },
            ],
          },
        ]}
      />

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={selectedVehicle ? 'Update Vehicle Properties' : 'Register New Fleet Asset'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {formError && (
            <div className="bg-rose-500/15 border border-rose-500/30 text-rose-400 p-3 rounded-lg text-xs font-semibold flex items-center gap-2">
              <Info size={14} className="shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Registration Number</label>
              <input
                type="text"
                value={regNumber}
                onChange={(e) => setRegNumber(e.target.value)}
                placeholder="e.g. V-109"
                disabled={!!selectedVehicle} // Cannot edit registration number once locked
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none disabled:opacity-50"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Model</label>
              <input
                type="text"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="e.g. Freightliner"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Vehicle Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="Semi">Semi Truck</option>
                <option value="Truck">Box Truck</option>
                <option value="Van">Cargo Van</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Initial Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="Available">Available</option>
                <option value="On Trip">On Trip</option>
                <option value="In Shop">In Shop</option>
                <option value="Retired">Retired</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Max Capacity (lbs)</label>
              <input
                type="number"
                value={loadCapacity}
                onChange={(e) => setLoadCapacity(e.target.value)}
                placeholder="e.g. 45000"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Acquisition Cost ($)</label>
              <input
                type="number"
                value={acqCost}
                onChange={(e) => setAcqCost(e.target.value)}
                placeholder="e.g. 135000"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Odometer (mi)</label>
              <input
                type="number"
                value={odometer}
                onChange={(e) => setOdometer(e.target.value)}
                placeholder="e.g. 15000"
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Operating Region</label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value as any)}
                className="w-full bg-brand-darkBg border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none"
              >
                <option value="North">North</option>
                <option value="South">South</option>
                <option value="East">East</option>
                <option value="West">West</option>
              </select>
            </div>
          </div>

          <div className="border-t border-gray-800/80 pt-4 flex justify-end gap-2 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={actionLoading}
              className="bg-brand-amber hover:bg-brand-amber/90 text-[#0A0D12] px-5 py-2.5 rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {actionLoading && <Loader2 size={13} className="animate-spin" />}
              <span>{selectedVehicle ? 'Save Modifications' : 'Register Asset'}</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
export default VehicleRegistry;
