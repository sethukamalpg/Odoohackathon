import React from 'react';
import { Check, MoveRight, Wrench, X } from 'lucide-react';

interface StatusBadgeProps {
  status: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const normalized = status.toLowerCase();

  if (normalized === 'available' || normalized === 'completed') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
        <Check size={12} className="stroke-[3]" />
        <span>{status}</span>
      </span>
    );
  }

  if (normalized === 'on trip' || normalized === 'dispatched') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-500/10 text-sky-400 border border-sky-500/20 animate-pulse-once">
        <MoveRight size={12} className="stroke-[3]" />
        <span>{status}</span>
      </span>
    );
  }

  if (normalized === 'in shop' || normalized === 'maintenance' || normalized === 'pending' || normalized === 'in progress') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-brand-amber border border-amber-500/20">
        <Wrench size={12} />
        <span>{status}</span>
      </span>
    );
  }

  // Retired, Suspended, Cancelled
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
      <X size={12} className="stroke-[3]" />
      <span>{status}</span>
    </span>
  );
};
export default StatusBadge;
