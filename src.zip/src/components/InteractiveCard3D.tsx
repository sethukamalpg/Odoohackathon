import React, { useRef, useState, useEffect } from 'react';

interface InteractiveCard3DProps {
  src: string;
  alt: string;
  hasContinuousFloat?: boolean;
  hasContinuousRotate?: boolean;
  glowColor?: string; // e.g. rgba(245, 166, 35, 0.15)
  maxTilt?: number; // max tilt angle in degrees
  className?: string;
  aspectRatio?: string;
}

export const InteractiveCard3D: React.FC<InteractiveCard3DProps> = ({
  src,
  alt,
  hasContinuousFloat = false,
  hasContinuousRotate = false,
  glowColor,
  maxTilt = 10,
  className = '',
  aspectRatio = 'aspect-video',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const [imageLoaded, setImageLoaded] = useState(false);

  // 3D Parallax Tilt effect on Hover
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left; 
    const y = e.clientY - rect.top;  

    const xc = rect.width / 2;
    const yc = rect.height / 2;

    const angleX = ((yc - y) / yc) * maxTilt;
    const angleY = ((x - xc) / xc) * maxTilt;

    card.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) scale3d(1.03, 1.03, 1.03)`;
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (!card) return;

    card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`relative select-none ${className}`}
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Background glow helper */}
      {glowColor && (
        <div
          className="absolute inset-0 rounded-2xl pointer-events-none blur-2xl transition-opacity duration-300"
          style={{
            background: `radial-gradient(circle at center, ${glowColor}, transparent)`,
            transform: 'translateZ(-10px)',
          }}
        />
      )}

      {/* Frame Card container */}
      <div
        ref={cardRef}
        style={{
          transformStyle: 'preserve-3d',
          transition: 'transform 0.15s ease-out, box-shadow 0.3s ease-out',
        }}
        className={`w-full ${aspectRatio} rounded-2xl border border-gray-800/80 bg-brand-panel p-2 shadow-2xl relative overflow-hidden transition-all`}
      >
        {/* Glass reflection overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none z-10" />

        {/* Loading Skeleton */}
        {!imageLoaded && (
          <div className="absolute inset-2 rounded-xl bg-gray-800/40 animate-pulse flex items-center justify-center text-xs text-gray-600 font-bold uppercase tracking-wider">
            Loading Asset...
          </div>
        )}

        {/* Floating animated image core */}
        <img
          src={src}
          alt={alt}
          onLoad={() => setImageLoaded(true)}
          loading="lazy"
          style={{
            transform: 'translateZ(10px)',
          }}
          className={`w-full h-full object-cover rounded-xl transition-opacity duration-500 ${
            imageLoaded ? 'opacity-90' : 'opacity-0'
          } ${hasContinuousFloat ? 'animate-float-bounce' : ''} ${
            hasContinuousRotate ? 'animate-float-rotate' : ''
          }`}
        />
      </div>

      {/* Embedded specific animation styles */}
      <style>{`
        @keyframes floatBounce {
          0%, 100% { transform: translateZ(10px) translateY(0); }
          50% { transform: translateZ(10px) translateY(-6px); }
        }
        @keyframes floatRotate {
          0%, 100% { transform: translateZ(10px) translateY(0) rotate(0deg); }
          50% { transform: translateZ(10px) translateY(-4px) rotate(1.5deg); }
        }
        .animate-float-bounce {
          animation: floatBounce 4s ease-in-out infinite;
        }
        .animate-float-rotate {
          animation: floatRotate 5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default InteractiveCard3D;
