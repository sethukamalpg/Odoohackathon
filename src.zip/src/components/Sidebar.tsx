import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Truck,
  Users,
  Navigation,
  Wrench,
  Fuel,
  BarChart3,
  Settings,
  LogOut,
  ShieldCheck
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { user, logout, hasRole } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) return null;

  // Sidebar link details
  const navItems = [
    {
      label: 'Dashboard',
      path: '/dashboard',
      icon: LayoutDashboard,
      roles: ['Admin', 'Dispatcher', 'Manager'],
    },
    {
      label: 'Vehicles',
      path: '/vehicles',
      icon: Truck,
      roles: ['Admin', 'Dispatcher', 'Manager'],
    },
    {
      label: 'Drivers',
      path: '/drivers',
      icon: Users,
      roles: ['Admin', 'Dispatcher', 'Manager'],
    },
    {
      label: 'Trip Dispatcher',
      path: '/dispatch',
      icon: Navigation,
      roles: ['Admin', 'Dispatcher', 'Manager'],
    },
    {
      label: 'Maintenance',
      path: '/maintenance',
      icon: Wrench,
      roles: ['Admin', 'Dispatcher', 'Manager'],
    },
    {
      label: 'Fuel & Expenses',
      path: '/expenses',
      icon: Fuel,
      roles: ['Admin', 'Dispatcher', 'Manager'],
    },
    {
      label: 'Reports & Analytics',
      path: '/reports',
      icon: BarChart3,
      roles: ['Admin', 'Manager'], // Reports restricted to Admin/Manager
    },
    {
      label: 'Settings & RBAC',
      path: '/settings',
      icon: Settings,
      roles: ['Admin'], // Settings restricted to Admin only
    },
  ];

  return (
    <aside className="w-64 bg-brand-panel border-r border-gray-800/80 flex flex-col h-screen shrink-0 text-gray-300">
      {/* Platform Title */}
      <div className="p-6 border-b border-gray-800/60 flex items-center gap-3">
        <div className="bg-brand-amber/10 p-2 rounded-lg text-brand-amber">
          <ShieldCheck size={22} className="stroke-[2.5]" />
        </div>
        <div>
          <h1 className="font-bold text-white text-lg tracking-wide font-heading leading-tight">TransitOps</h1>
          <span className="text-[10px] uppercase font-bold text-brand-teal tracking-widest leading-none block mt-0.5">Fleet Command</span>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => {
          if (!hasRole(item.roles)) return null;

          const isActive = location.pathname === item.path;
          const Icon = item.icon;

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3.5 px-4 py-3 rounded-lg text-sm font-semibold transition-all relative overflow-hidden group ${
                isActive
                  ? 'text-white bg-brand-amber/10'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800/30'
              }`}
            >
              {/* Amber left active indicator */}
              {isActive && (
                <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-brand-amber" />
              )}
              
              <Icon
                size={18}
                className={`transition-colors ${
                  isActive ? 'text-brand-amber' : 'text-gray-500 group-hover:text-gray-300'
                }`}
              />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* User Session profile block */}
      <div className="p-4 border-t border-gray-800/60 bg-[#0B0F16]/50">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-brand-amber/10 flex items-center justify-center text-brand-amber border border-brand-amber/20 font-bold font-heading">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate leading-tight">{user.name}</p>
            <p className="text-xs text-brand-teal font-semibold mt-0.5 uppercase tracking-wider leading-none">
              {user.role}
            </p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="w-full mt-4 flex items-center justify-center gap-2 px-3 py-2 text-xs font-bold bg-gray-800 hover:bg-rose-500/10 hover:text-rose-400 text-gray-400 rounded-lg border border-gray-700/40 hover:border-rose-500/20 transition-all"
        >
          <LogOut size={13} />
          <span>Sign Out Command</span>
        </button>
      </div>
    </aside>
  );
};
export default Sidebar;
