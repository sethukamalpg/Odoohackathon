import React, { useEffect, useState, useRef } from 'react';
import type { LucideIcon } from 'lucide-react';

interface KPICardProps {
  title: string;
  value: number | string;
  icon?: LucideIcon;
  subtitle?: string;
  prefix?: string;
  suffix?: string;
  accentColor?: 'amber' | 'teal';
  highlighted?: boolean;
}

export const KPICard: React.FC<KPICardProps> = ({
  title,
  value,
  icon: Icon,
  subtitle,
  prefix = '',
  suffix = '',
  accentColor = 'amber',
  highlighted = false,
}) => {
  const [displayValue, setDisplayValue] = useState<number | string>(typeof value === 'number' ? 0 : value);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof value !== 'number') {
      setDisplayValue(value);
      return;
    }

    const duration = 800; // ms
    const frameRate = 1000 / 60; // 60 fps
    const totalFrames = Math.round(duration / frameRate);
    let frame = 0;

    const timer = setInterval(() => {
      frame++;
      const progress = frame / totalFrames;
      // Ease out quadratic
      const easeProgress = progress * (2 - progress);
      const current = Math.round(value * easeProgress * 10) / 10;
      
      setDisplayValue(current);

      if (frame >= totalFrames) {
        setDisplayValue(value);
        clearInterval(timer);
      }
    }, frameRate);

    return () => clearInterval(timer);
  }, [value]);

  // 3D Parallax Mouse Hover Handlers
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left; // x coordinate within the element.
    const y = e.clientY - rect.top;  // y coordinate within the element.

    const xc = rect.width / 2;
    const yc = rect.height / 2;

    // Calculate rotation angles (max 12 degrees)
    const angleX = (yc - y) / 8;
    const angleY = (x - xc) / 8;

    // Apply transform style dynamically
    card.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) scale3d(1.02, 1.02, 1.02)`;
    card.style.boxShadow = '0 25px 50px -12px rgba(0, 0, 0, 0.5)';
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (!card) return;

    // Reset styles back to default
    card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
    card.style.boxShadow = '';
  };

  // Determine classes based on highlighted state
  const bgClass = highlighted 
    ? (accentColor === 'teal' ? 'bg-brand-teal text-[#0A0D12]' : 'bg-brand-amber text-[#0A0D12]')
    : 'bg-brand-panel border-x border-b border-gray-800/40 hover:border-gray-700/60';

  const topBorderClass = highlighted 
    ? '' 
    : (accentColor === 'teal' ? 'border-t-2 border-t-brand-teal' : 'border-t-2 border-t-brand-amber');

  const titleClass = highlighted ? 'text-[#0A0D12]/70' : 'text-gray-400';
  const valClass = highlighted ? 'text-[#0A0D12]' : 'text-white';
  const subtitleClass = highlighted ? 'text-[#0A0D12]/70' : 'text-gray-500';
  const iconBgClass = highlighted 
    ? 'bg-black/10 text-black' 
    : (accentColor === 'teal' ? 'bg-brand-teal/10 text-brand-teal' : 'bg-brand-amber/10 text-brand-amber');

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        transformStyle: 'preserve-3d',
        transition: 'transform 0.1s ease-out, box-shadow 0.2s ease-out',
      }}
      className={`${bgClass} ${topBorderClass} rounded-xl p-5 shadow-lg relative overflow-hidden cursor-pointer`}
    >
      {/* Light sheen effect on hover */}
      {!highlighted && (
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent opacity-0 hover:opacity-100 transition-opacity pointer-events-none" />
      )}

      <div className="flex justify-between items-start relative z-10" style={{ transform: 'translateZ(20px)' }}>
        <div>
          <p className={`text-xs font-semibold uppercase tracking-wider font-heading ${titleClass}`}>{title}</p>
          <h3 className={`text-3xl lg:text-4xl font-bold font-heading mt-2 leading-none ${valClass}`}>
            {prefix}
            {typeof displayValue === 'number' ? displayValue.toLocaleString() : displayValue}
            {suffix}
          </h3>
        </div>
        {Icon && (
          <div className={`p-2 rounded-lg ${iconBgClass}`}>
            <Icon size={20} />
          </div>
        )}
      </div>
      {subtitle && (
        <p className={`text-xs mt-3 flex items-center gap-1 font-medium relative z-10 ${subtitleClass}`} style={{ transform: 'translateZ(10px)' }}>
          {subtitle}
        </p>
      )}
    </div>
  );
};

export default KPICard;
