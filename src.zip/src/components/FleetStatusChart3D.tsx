import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface FleetStatusChart3DProps {
  distribution: { name: string; value: number }[];
}

export const FleetStatusChart3D: React.FC<FleetStatusChart3DProps> = ({ distribution }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene setup
    const scene = new THREE.Scene();

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 7, 10);
    camera.lookAt(0, 0, 0);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // 4. Create main group
    const chartGroup = new THREE.Group();
    scene.add(chartGroup);

    // Color definitions
    const COLORS = {
      'Available': 0x2DD4BF,  // Teal
      'On Trip': 0x38BDF8,     // Sky Blue
      'In Shop': 0xF5A623,     // Amber
      'Retired': 0xFB7185,     // Rose
    };

    // 5. Build Grid helper as the base plate
    const gridHelper = new THREE.GridHelper(8, 8, 0x1F2937, 0x111827);
    gridHelper.position.y = -0.5;
    chartGroup.add(gridHelper);

    // 6. Build 3D Pillars for the distribution data
    const maxVal = Math.max(...distribution.map((d) => d.value), 1);
    const pillars: THREE.Mesh[] = [];

    distribution.forEach((data, index) => {
      const val = data.value;
      const pct = val / maxVal;
      const pillarHeight = Math.max(pct * 4, 0.2); // Min height of 0.2 for visual representation

      // Box geometry for the 3D columns
      const geometry = new THREE.BoxGeometry(0.8, pillarHeight, 0.8);
      
      // Material with glowing emission properties
      const colorHex = COLORS[data.name as keyof typeof COLORS] || 0x9CA3AF;
      const material = new THREE.MeshStandardMaterial({
        color: colorHex,
        roughness: 0.2,
        metalness: 0.1,
        transparent: true,
        opacity: 0.9,
      });

      const pillar = new THREE.Mesh(geometry, material);

      // Position pillars in a straight line or cross formation
      const xOffset = (index - (distribution.length - 1) / 2) * 1.6;
      pillar.position.set(xOffset, pillarHeight / 2 - 0.5, 0);
      chartGroup.add(pillar);
      pillars.push(pillar);
    });

    // 7. Add Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(5, 10, 5);
    scene.add(dirLight);

    const pointLight = new THREE.PointLight(0xF5A623, 1, 15);
    pointLight.position.set(0, 3, 0);
    scene.add(pointLight);

    // 8. Mouse drag controls
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const handleMouseDown = () => {
      isDragging = true;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;

      const deltaMove = {
        x: e.clientX - previousMousePosition.x,
        y: e.clientY - previousMousePosition.y,
      };

      chartGroup.rotation.y += deltaMove.x * 0.005;

      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
      isDragging = false;
    };

    const recordMousePosition = (e: MouseEvent) => {
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const canvas = renderer.domElement;
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('mousedown', recordMousePosition);

    // Touch support
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        previousMousePosition = {
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
        };
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const deltaMove = {
        x: e.touches[0].clientX - previousMousePosition.x,
        y: e.touches[0].clientY - previousMousePosition.y,
      };
      chartGroup.rotation.y += deltaMove.x * 0.005;
      previousMousePosition = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
      };
    };

    canvas.addEventListener('touchstart', handleTouchStart);
    canvas.addEventListener('touchmove', handleTouchMove);
    canvas.addEventListener('touchend', handleMouseUp);

    // 9. Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();

      // Automatic slow rotation when not dragging
      if (!isDragging) {
        chartGroup.rotation.y = elapsedTime * 0.25;
      }

      // Dynamic floating bounce animation for pillars
      pillars.forEach((pillar, idx) => {
        pillar.position.y += Math.sin(elapsedTime * 2 + idx) * 0.002;
      });

      renderer.render(scene, camera);
    };

    animate();

    // 10. Handle Resize
    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      canvas.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('mousedown', recordMousePosition);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleMouseUp);
      cancelAnimationFrame(animationFrameId);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [distribution]);

  return (
    <div className="relative w-full h-full min-h-[220px] flex items-center justify-center cursor-grab active:cursor-grabbing select-none">
      <div ref={containerRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
};

export default FleetStatusChart3D;
