import React, { useRef, useState, useEffect } from 'react';

interface ParallaxImage3DProps {
  src: string;
  alt: string;
  effect?: 'ken-burns' | 'float' | 'none';
  maxTilt?: number; // max tilt angle in degrees
  overlayGradient?: boolean; // dark fade overlay (for text legibility)
  overlayColorGrade?: boolean; // warm/cool dark tint overlay
  className?: string;
  aspectRatio?: string;
}

export const ParallaxImage3D: React.FC<ParallaxImage3DProps> = ({
  src,
  alt,
  effect = 'none',
  maxTilt = 8,
  overlayGradient = false,
  overlayColorGrade = false,
  className = '',
  aspectRatio = 'aspect-video',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);

  // Dynamic Mouse Parallax Tilt
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left; 
    const y = e.clientY - rect.top;  

    const xc = rect.width / 2;
    const yc = rect.height / 2;

    const angleX = ((yc - y) / yc) * maxTilt;
    const angleY = ((x - xc) / xc) * maxTilt;

    card.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) scale3d(1.02, 1.02, 1.02)`;
    card.style.boxShadow = `${-angleY * 2}px ${20 + angleX * 2}px 40px rgba(0, 0, 0, 0.65)`;
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (!card) return;

    card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
    card.style.boxShadow = '';
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`relative select-none overflow-hidden rounded-2xl ${className}`}
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
    >
      {/* 3D Framed Card */}
      <div
        ref={cardRef}
        style={{
          transformStyle: 'preserve-3d',
          transition: 'transform 0.15s ease-out, box-shadow 0.3s ease-out',
        }}
        className={`w-full ${aspectRatio} rounded-2xl border border-gray-800/80 bg-brand-panel shadow-2xl relative overflow-hidden`}
      >
        {/* Loading Skeleton */}
        {!loaded && (
          <div className="absolute inset-0 bg-gray-900/60 animate-pulse flex items-center justify-center text-xs text-gray-500 font-bold uppercase tracking-widest z-20">
            Syncing telemetry stream...
          </div>
        )}

        {/* Dynamic Overlay 1: Legibility gradient overlay */}
        {overlayGradient && (
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0D12] via-[#0A0D12]/20 to-transparent opacity-90 z-10 pointer-events-none" />
        )}

        {/* Dynamic Overlay 2: Theme color grade/vignette overlay mapping to dark theme accents */}
        {overlayColorGrade && (
          <div className="absolute inset-0 bg-gradient-to-br from-brand-amber/5 via-[#0A0D12]/30 to-[#0A0D12]/75 mix-blend-multiply z-10 pointer-events-none" />
        )}

        {/* Glass reflection cover */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent opacity-60 pointer-events-none z-10" />

        {/* Image Source core */}
        <img
          src={src}
          alt={alt}
          onLoad={() => setLoaded(true)}
          loading="lazy"
          className={`w-full h-full object-cover rounded-xl transition-all duration-700 ${
            loaded ? 'opacity-85 scale-100' : 'opacity-0 scale-95'
          } ${effect === 'ken-burns' ? 'animate-ken-burns' : ''} ${
            effect === 'float' ? 'animate-float-bounce' : ''
          }`}
        />
      </div>

      <style>{`
        @keyframes kenBurns {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.06); }
        }
        @keyframes floatBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        .animate-ken-burns {
          animation: kenBurns 12s linear infinite;
        }
        .animate-float-bounce {
          animation: floatBounce 3.5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default ParallaxImage3D;
