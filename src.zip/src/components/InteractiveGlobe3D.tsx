import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const InteractiveGlobe3D: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene Setup
    const scene = new THREE.Scene();

    // 2. Camera Setup
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 18;

    // 3. Renderer Setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // 4. Create Globe Group
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // Color definitions matching the design theme
    const colorTeal = new THREE.Color('#2DD4BF');
    const colorAmber = new THREE.Color('#F5A623');
    const colorDark = new THREE.Color('#1F2937');

    // 5. Build Globe Particles (Earth Mesh points)
    const particleCount = 600;
    const globeRadius = 6;
    const particleGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      // Golden spiral distribution for even point placement on sphere
      const phi = Math.acos(-1 + (2 * i) / particleCount);
      const theta = Math.sqrt(particleCount * Math.PI) * phi;

      const x = globeRadius * Math.sin(phi) * Math.cos(theta);
      const y = globeRadius * Math.sin(phi) * Math.sin(theta);
      const z = globeRadius * Math.cos(phi);

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      // Color variation between teal and amber
      const mixedColor = new THREE.Color().lerpColors(
        colorTeal,
        colorAmber,
        Math.random() * 0.4
      );

      colors[i * 3] = mixedColor.r;
      colors[i * 3 + 1] = mixedColor.g;
      colors[i * 3 + 2] = mixedColor.b;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    // Custom glowing dot shader/material for particles
    const particleMaterial = new THREE.PointsMaterial({
      size: 0.18,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
    });

    const globeParticles = new THREE.Points(particleGeometry, particleMaterial);
    globeGroup.add(globeParticles);

    // 6. Build Wireframe Atmosphere rings
    const ringGeometry = new THREE.RingGeometry(globeRadius + 0.5, globeRadius + 0.52, 64);
    const ringMaterial = new THREE.MeshBasicMaterial({
      color: colorTeal,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.15,
    });
    const atmosphereRing1 = new THREE.Mesh(ringGeometry, ringMaterial);
    globeGroup.add(atmosphereRing1);

    const atmosphereRing2 = atmosphereRing1.clone();
    atmosphereRing2.rotation.x = Math.PI / 2;
    globeGroup.add(atmosphereRing2);

    // 7. Dynamic Moving Fleet Dispatch Routes (Spline arcs)
    const routesCount = 5;
    const routesArray: {
      line: THREE.Line;
      vehicle: THREE.Mesh;
      spline: THREE.CatmullRomCurve3;
      speed: number;
      progress: number;
    }[] = [];

    // Helper to get random point on sphere surface
    const getRandomSpherePoint = (radius: number) => {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      return new THREE.Vector3(
        radius * Math.sin(phi) * Math.cos(theta),
        radius * Math.sin(phi) * Math.sin(theta),
        radius * Math.cos(phi)
      );
    };

    for (let i = 0; i < routesCount; i++) {
      const start = getRandomSpherePoint(globeRadius);
      const end = getRandomSpherePoint(globeRadius);

      // Create an arc elevation mid-point
      const midPoint = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);
      const distance = start.distanceTo(end);
      midPoint.normalize().multiplyScalar(globeRadius + distance * 0.25); // Push arc outward

      const spline = new THREE.CatmullRomCurve3([start, midPoint, end]);
      const points = spline.getPoints(50);
      const curveGeometry = new THREE.BufferGeometry().setFromPoints(points);

      const curveMaterial = new THREE.LineBasicMaterial({
        color: colorAmber,
        transparent: true,
        opacity: 0.35,
      });

      const line = new THREE.Line(curveGeometry, curveMaterial);
      globeGroup.add(line);

      // Create a small moving dot representing a fleet vehicle on route
      const vehicleGeo = new THREE.SphereGeometry(0.12, 8, 8);
      const vehicleMat = new THREE.MeshBasicMaterial({ color: colorTeal });
      const vehicle = new THREE.Mesh(vehicleGeo, vehicleMat);
      globeGroup.add(vehicle);

      routesArray.push({
        line,
        vehicle,
        spline,
        speed: 0.003 + Math.random() * 0.005,
        progress: Math.random(),
      });
    }

    // 8. Add Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    scene.add(directionalLight);

    // 9. Interactivity: Mouse dragging and parallax orientation
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };
    const targetRotation = { x: 0, y: 0 };
    const currentRotation = { x: 0, y: 0 };

    const handleMouseDown = () => {
      isDragging = true;
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      const mouseX = ((e.clientX - rect.left) / width) * 2 - 1;
      const mouseY = -((e.clientY - rect.top) / height) * 2 + 1;

      // Parallax orientation tilting target
      targetRotation.y = mouseX * 0.4;
      targetRotation.x = -mouseY * 0.4;

      if (!isDragging) return;

      const deltaMove = {
        x: e.clientX - previousMousePosition.x,
        y: e.clientY - previousMousePosition.y,
      };

      globeGroup.rotation.y += deltaMove.x * 0.005;
      globeGroup.rotation.x += deltaMove.y * 0.005;

      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
      isDragging = false;
    };

    const recordMousePosition = (e: MouseEvent) => {
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    // Add event listeners to the canvas element
    const canvas = renderer.domElement;
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('mousedown', recordMousePosition);

    // Touch support for mobile devices
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        previousMousePosition = {
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
        };
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const deltaMove = {
        x: e.touches[0].clientX - previousMousePosition.x,
        y: e.touches[0].clientY - previousMousePosition.y,
      };
      globeGroup.rotation.y += deltaMove.x * 0.005;
      globeGroup.rotation.x += deltaMove.y * 0.005;
      previousMousePosition = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
      };
    };

    canvas.addEventListener('touchstart', handleTouchStart);
    canvas.addEventListener('touchmove', handleTouchMove);
    canvas.addEventListener('touchend', handleMouseUp);

    // 10. Animation Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      // Automatic slow rotation if not dragging
      if (!isDragging) {
        globeGroup.rotation.y += 0.0015;
      }

      // Parallax smooth interpolation (lerp)
      currentRotation.x += (targetRotation.x - currentRotation.x) * 0.05;
      currentRotation.y += (targetRotation.y - currentRotation.y) * 0.05;

      // Apply subtle orientation tilts to the camera for interactive parallax feel
      camera.position.x = currentRotation.y * 5;
      camera.position.y = currentRotation.x * 5;
      camera.lookAt(scene.position);

      // Rotate atmosphere rings in opposite directions
      atmosphereRing1.rotation.z += 0.002;
      atmosphereRing2.rotation.z -= 0.001;

      // Update vehicle positions along splines
      routesArray.forEach((route) => {
        route.progress += route.speed;
        if (route.progress > 1) {
          route.progress = 0;
        }
        const point = route.spline.getPointAt(route.progress);
        route.vehicle.position.copy(point);
      });

      renderer.render(scene, camera);
    };

    animate();

    // 11. Handle Resize
    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup on unmount
    return () => {
      window.removeEventListener('resize', handleResize);
      canvas.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('mousedown', recordMousePosition);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleMouseUp);
      cancelAnimationFrame(animationFrameId);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div className="relative w-full h-full min-h-[400px] flex items-center justify-center cursor-grab active:cursor-grabbing select-none">
      {/* 3D WebGL Canvas Mount point */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full" />
      
      {/* Visual Overlay elements */}
      <div className="absolute bottom-6 left-6 z-10 pointer-events-none bg-brand-panel/80 border border-gray-800/80 rounded-xl px-4 py-3 backdrop-blur-md shadow-2xl">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-brand-teal animate-pulse" />
          <span className="text-[10px] uppercase font-bold text-white tracking-wider font-heading">Interactive Globe Simulator</span>
        </div>
        <p className="text-[9px] text-gray-500 font-semibold mt-1 uppercase">Click & drag to rotate global routes</p>
      </div>
    </div>
  );
};

export default InteractiveGlobe3D;
