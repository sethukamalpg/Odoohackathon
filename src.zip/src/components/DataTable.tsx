import React, { useState, useMemo } from 'react';
import { Search, ChevronDown, ChevronUp, SlidersHorizontal, ArrowUpDown } from 'lucide-react';

export interface Column<T> {
  key: keyof T | string;
  label: string;
  sortable?: boolean;
  render?: (row: T) => React.ReactNode;
}

export interface FilterOption {
  key: string;
  label: string;
  options: { label: string; value: string }[];
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  searchPlaceholder?: string;
  searchKey?: keyof T;
  filterOptions?: FilterOption[];
  emptyState?: React.ReactNode;
}

export function DataTable<T extends Record<string, any>>({
  columns,
  data,
  searchPlaceholder = 'Search...',
  searchKey,
  filterOptions = [],
  emptyState,
}: DataTableProps<T>) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [activeFilters, setActiveFilters] = useState<Record<string, string>>({});
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Handle filter change
  const handleFilterChange = (key: string, value: string) => {
    setActiveFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
    setCurrentPage(1);
  };

  // Clear all filters
  const handleResetFilters = () => {
    setActiveFilters({});
    setSearchTerm('');
    setCurrentPage(1);
  };

  // Toggle Sorting
  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  // Filtered and Sorted Data
  const processedData = useMemo(() => {
    let result = [...data];

    // 1. Search filter
    if (searchTerm.trim() !== '' && searchKey) {
      const searchLower = searchTerm.toLowerCase();
      result = result.filter((item) => {
        const val = item[searchKey as string];
        return val ? String(val).toLowerCase().includes(searchLower) : false;
      });
    }

    // 2. Dropdown filters
    Object.entries(activeFilters).forEach(([key, value]) => {
      if (value !== '') {
        result = result.filter((item) => String(item[key]) === value);
      }
    });

    // 3. Sorting
    if (sortKey) {
      result.sort((a, b) => {
        let valA = a[sortKey];
        let valB = b[sortKey];

        // Format dates or convert to numbers if possible
        if (typeof valA === 'string' && !isNaN(Date.parse(valA)) && isNaN(Number(valA))) {
          valA = new Date(valA).getTime();
          valB = new Date(valB).getTime();
        }

        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortDirection === 'asc' ? valA - valB : valB - valA;
        }

        const strA = String(valA).toLowerCase();
        const strB = String(valB).toLowerCase();

        if (strA < strB) return sortDirection === 'asc' ? -1 : 1;
        if (strA > strB) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [data, searchTerm, searchKey, activeFilters, sortKey, sortDirection]);

  // Pagination bounds
  const totalPages = Math.ceil(processedData.length / itemsPerPage);
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return processedData.slice(startIndex, startIndex + itemsPerPage);
  }, [processedData, currentPage]);

  const hasActiveFilters = Object.values(activeFilters).some(v => v !== '') || searchTerm !== '';

  return (
    <div className="space-y-4">
      {/* Table Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center">
        {/* Search */}
        {searchKey && (
          <div className="relative flex-1 max-w-md">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 pointer-events-none">
              <Search size={16} />
            </span>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={searchPlaceholder}
              className="w-full bg-brand-panel border border-gray-800 focus:border-brand-amber rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-gray-500 focus:outline-none transition-all"
            />
          </div>
        )}

        {/* Dynamic Filters */}
        <div className="flex flex-wrap gap-2 items-center">
          {filterOptions.map((filter) => (
            <div key={filter.key} className="relative">
              <select
                value={activeFilters[filter.key] || ''}
                onChange={(e) => handleFilterChange(filter.key, e.target.value)}
                className="bg-brand-panel border border-gray-800 focus:border-brand-amber rounded-lg px-3 py-2 text-xs text-gray-300 font-medium focus:outline-none appearance-none pr-8 cursor-pointer"
              >
                <option value="">{filter.label}</option>
                {filter.options.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
              <span className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-gray-500 pointer-events-none">
                <ChevronDown size={14} />
              </span>
            </div>
          ))}

          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="text-xs font-semibold text-brand-amber/80 hover:text-brand-amber px-2 py-1 transition-all"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Main Table Panel */}
      <div className="bg-brand-panel border border-gray-800/60 rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#181E2B]/40 border-b border-gray-800 text-gray-400 text-xs font-semibold uppercase tracking-wider">
                {columns.map((col) => (
                  <th
                    key={col.key.toString()}
                    className={`px-5 py-4 ${col.sortable ? 'cursor-pointer select-none hover:bg-gray-800/20 hover:text-white' : ''}`}
                    onClick={() => col.sortable && handleSort(col.key.toString())}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>{col.label}</span>
                      {col.sortable && (
                        <span>
                          {sortKey === col.key ? (
                            sortDirection === 'asc' ? <ChevronUp size={14} /> : <ChevronDown size={14} />
                          ) : (
                            <ArrowUpDown size={12} className="opacity-40" />
                          )}
                        </span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/40 text-sm text-gray-300">
              {paginatedData.length > 0 ? (
                paginatedData.map((row, rIdx) => (
                  <tr key={row.id || rIdx} className="hover:bg-[#181E2B]/20 transition-all">
                    {columns.map((col) => (
                      <td key={col.key.toString()} className="px-5 py-3.5 whitespace-nowrap">
                        {col.render ? col.render(row) : row[col.key as string] ?? '—'}
                      </td>
                    ))}
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={columns.length} className="px-5 py-12 text-center">
                    {emptyState || (
                      <div className="flex flex-col items-center justify-center text-gray-500 py-6">
                        <SlidersHorizontal size={36} className="text-gray-600 mb-2" />
                        <p className="font-semibold text-gray-400">No matching fleet data found</p>
                        <p className="text-xs mt-1">Try adjusting your filters or search terms.</p>
                      </div>
                    )}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        {totalPages > 1 && (
          <div className="bg-brand-panel border-t border-gray-800/40 px-5 py-4 flex items-center justify-between">
            <span className="text-xs text-gray-500">
              Showing <span className="font-semibold text-gray-300">{(currentPage - 1) * itemsPerPage + 1}</span> to{' '}
              <span className="font-semibold text-gray-300">
                {Math.min(currentPage * itemsPerPage, processedData.length)}
              </span>{' '}
              of <span className="font-semibold text-gray-300">{processedData.length}</span> results
            </span>
            <div className="flex gap-1">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((c) => c - 1)}
                className="px-2.5 py-1.5 rounded bg-gray-800 text-xs font-semibold text-gray-300 hover:bg-gray-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                Previous
              </button>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((c) => c + 1)}
                className="px-2.5 py-1.5 rounded bg-gray-800 text-xs font-semibold text-gray-300 hover:bg-gray-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
export default DataTable;
