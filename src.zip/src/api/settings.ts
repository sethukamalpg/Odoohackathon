import { apiRequest } from './client';

export interface UserRoleMapping {
  id: number;
  name: string;
  email: string;
  role: 'Admin' | 'Dispatcher' | 'Manager';
  role_id: number;
  created_at: string;
}

export const fetchUsersWithRoles = async (): Promise<UserRoleMapping[]> => {
  return apiRequest('/settings/users');
};

export const updateUserRole = async (userId: number, roleId: number) => {
  return apiRequest(`/settings/users/${userId}/role`, {
    method: 'PUT',
    body: JSON.stringify({ role_id: roleId }),
  });
};
