import { apiRequest } from './client';

export const loginUser = async (credentials: { email: string; password?: string }) => {
  return apiRequest('/login', {
    method: 'POST',
    body: JSON.stringify(credentials),
    isAuthServer: true,
  });
};

export const registerUser = async (userData: { name: string; email: string; password?: string; roleName?: string }) => {
  return apiRequest('/register', {
    method: 'POST',
    body: JSON.stringify(userData),
    isAuthServer: true,
  });
};

export const getMe = async () => {
  return apiRequest('/me', {
    method: 'GET',
    isAuthServer: true,
  });
};
