const BASE_URL = 'http://localhost:5002/api';
const AUTH_URL = 'http://localhost:5001/auth';

interface RequestOptions extends RequestInit {
  isAuthServer?: boolean;
}

/**
 * Custom fetch wrapper to handle authorization headers and JSON responses automatically.
 */
export const apiRequest = async (endpoint: string, options: RequestOptions = {}) => {
  const token = localStorage.getItem('transitops_token');
  const baseUrl = options.isAuthServer ? AUTH_URL : BASE_URL;

  const headers = new Headers(options.headers || {});
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const config: RequestInit = {
    ...options,
    headers,
  };

  const response = await fetch(`${baseUrl}${endpoint}`, config);

  // If response is file download, return blob/text
  const contentType = response.headers.get('Content-Type');
  if (contentType && contentType.includes('text/csv')) {
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to export report.');
    }
    return response.text();
  }

  let data;
  try {
    data = await response.json();
  } catch (err) {
    data = null;
  }

  if (!response.ok) {
    const errorMessage = data?.error || 'A network error occurred. Please try again.';
    const error = new Error(errorMessage);
    (error as any).status = response.status;
    throw error;
  }

  return data;
};
