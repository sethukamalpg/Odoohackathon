import { apiRequest } from './client';

export interface Trip {
  id: number;
  trip_number: string;
  vehicle_id: number;
  driver_id: number;
  source: string;
  destination: string;
  status: 'Draft' | 'Dispatched' | 'Completed' | 'Cancelled';
  cargo_weight: number;
  planned_distance: number;
  revenue: number;
  start_date: string;
  end_date: string | null;
  registration_number?: string;
  vehicle_model?: string;
  vehicle_odometer?: number;
  driver_name?: string;
}

export const fetchTrips = async (): Promise<Trip[]> => {
  return apiRequest('/trips');
};

export const dispatchTrip = async (trip: Omit<Trip, 'id' | 'revenue' | 'start_date' | 'end_date'>) => {
  return apiRequest('/trips', {
    method: 'POST',
    body: JSON.stringify(trip),
  });
};

export const completeTrip = async (id: number, completionData: { revenue: number; final_odometer?: number; fuel_consumed?: number }) => {
  return apiRequest(`/trips/${id}/complete`, {
    method: 'POST',
    body: JSON.stringify(completionData),
  });
};

export const cancelTrip = async (id: number) => {
  return apiRequest(`/trips/${id}/cancel`, {
    method: 'POST',
  });
};

export const dispatchDraftTrip = async (id: number) => {
  return apiRequest(`/trips/${id}/dispatch`, {
    method: 'POST',
  });
};
