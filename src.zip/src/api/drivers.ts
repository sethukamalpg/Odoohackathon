import { apiRequest } from './client';

export interface Driver {
  id: number;
  name: string;
  license_number: string;
  license_expiry_date: string;
  status: 'Available' | 'On Trip' | 'Suspended';
  safety_score: number;
  created_at: string;
}

export const fetchDrivers = async (): Promise<Driver[]> => {
  return apiRequest('/drivers');
};

export const fetchEligibleDrivers = async (): Promise<Driver[]> => {
  return apiRequest('/drivers/eligible');
};

export const createDriver = async (driver: Omit<Driver, 'id' | 'created_at'>) => {
  return apiRequest('/drivers', {
    method: 'POST',
    body: JSON.stringify(driver),
  });
};

export const updateDriver = async (id: number, driver: Omit<Driver, 'id' | 'created_at'>) => {
  return apiRequest(`/drivers/${id}`, {
    method: 'PUT',
    body: JSON.stringify(driver),
  });
};

export const deleteDriver = async (id: number) => {
  return apiRequest(`/drivers/${id}`, {
    method: 'DELETE',
  });
};
