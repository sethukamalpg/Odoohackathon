import { apiRequest } from './client';

export interface Vehicle {
  id: number;
  registration_number: string;
  model: string;
  type: string;
  status: 'Available' | 'On Trip' | 'In Shop' | 'Retired';
  max_load_capacity: number;
  acquisition_cost: number;
  odometer: number;
  region: 'North' | 'South' | 'East' | 'West';
  current_fuel_level: number;
  created_at: string;
}

export const fetchVehicles = async (): Promise<Vehicle[]> => {
  return apiRequest('/vehicles');
};

export const fetchEligibleVehicles = async (): Promise<Vehicle[]> => {
  return apiRequest('/vehicles/eligible');
};

export const createVehicle = async (vehicle: Omit<Vehicle, 'id' | 'created_at' | 'current_fuel_level'>) => {
  return apiRequest('/vehicles', {
    method: 'POST',
    body: JSON.stringify(vehicle),
  });
};

export const updateVehicle = async (id: number, vehicle: Omit<Vehicle, 'id' | 'created_at'>) => {
  return apiRequest(`/vehicles/${id}`, {
    method: 'PUT',
    body: JSON.stringify(vehicle),
  });
};

export const deleteVehicle = async (id: number) => {
  return apiRequest(`/vehicles/${id}`, {
    method: 'DELETE',
  });
};
