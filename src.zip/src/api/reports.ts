import { apiRequest } from './client';

export interface DashboardKPIs {
  kpis: {
    totalVehicles: number;
    activeVehicles: number;
    availableVehicles: number;
    vehiclesInMaintenance: number;
    activeTrips: number;
    pendingTrips: number;
    driversOnDuty: number;
    totalMaintenanceCost: number;
    totalRevenue: number;
    utilizationRate: number;
  };
  recentTrips: any[];
  fleetDistribution: { name: string; value: number }[];
}

export interface ReportsData {
  roi: any[];
  costs: any[];
  fuel: any[];
  utilization: any[];
  monthlyRevenue: { month: string; revenue: number }[];
}

export const fetchDashboardKPIs = async (filters?: { vehicleType?: string; status?: string; region?: string }): Promise<DashboardKPIs> => {
  let query = '';
  if (filters) {
    const params = new URLSearchParams();
    if (filters.vehicleType) params.append('vehicleType', filters.vehicleType);
    if (filters.status) params.append('status', filters.status);
    if (filters.region) params.append('region', filters.region);
    const paramStr = params.toString();
    if (paramStr) query = `?${paramStr}`;
  }
  return apiRequest(`/dashboard/kpi${query}`);
};

export const fetchReportsData = async (): Promise<ReportsData> => {
  return apiRequest('/reports/analytics');
};

/**
 * Downloads the requested CSV report using authenticated fetch.
 */
export const downloadReportCSV = async (reportType: 'roi' | 'costs' | 'fuel' | 'utilization') => {
  try {
    const csvContent = await apiRequest(`/reports/export/${reportType}`);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `transitops_${reportType}_report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (error) {
    console.error('Failed to export CSV report:', error);
    throw error;
  }
};
