import { apiRequest } from './client';

export interface MaintenanceLog {
  id: number;
  vehicle_id: number;
  description: string;
  cost: number;
  status: 'Pending' | 'In Progress' | 'Completed';
  logged_at: string;
  completed_at: string | null;
  registration_number?: string;
  vehicle_model?: string;
}

export const fetchMaintenanceLogs = async (): Promise<MaintenanceLog[]> => {
  return apiRequest('/maintenance');
};

export const createMaintenanceLog = async (log: Omit<MaintenanceLog, 'id' | 'logged_at' | 'completed_at'>) => {
  return apiRequest('/maintenance', {
    method: 'POST',
    body: JSON.stringify(log),
  });
};

export const closeMaintenanceLog = async (id: number, cost: number) => {
  return apiRequest(`/maintenance/${id}/complete`, {
    method: 'POST',
    body: JSON.stringify({ cost }),
  });
};
