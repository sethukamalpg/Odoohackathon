import { apiRequest } from './client';

export interface FuelLog {
  id: number;
  vehicle_id: number;
  liters: number;
  cost: number;
  logged_at: string;
  registration_number?: string;
  vehicle_model?: string;
}

export interface Expense {
  id: number;
  vehicle_id: number;
  category: 'Tolls' | 'Insurance' | 'Permits' | 'Other';
  amount: number;
  description: string;
  logged_at: string;
  registration_number?: string;
  vehicle_model?: string;
}

export const fetchFuelLogs = async (): Promise<FuelLog[]> => {
  return apiRequest('/fuel-logs');
};

export const createFuelLog = async (log: Omit<FuelLog, 'id' | 'logged_at'>) => {
  return apiRequest('/fuel-logs', {
    method: 'POST',
    body: JSON.stringify(log),
  });
};

export const fetchExpenses = async (): Promise<Expense[]> => {
  return apiRequest('/expenses');
};

export const createExpense = async (expense: Omit<Expense, 'id' | 'logged_at'>) => {
  return apiRequest('/expenses', {
    method: 'POST',
    body: JSON.stringify(expense),
  });
};
