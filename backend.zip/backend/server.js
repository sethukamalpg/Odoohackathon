const express = require('express');
const cors = require('cors');
require('dotenv').config();

const vehiclesRouter = require('./routes/vehicles');
const driversRouter = require('./routes/drivers');
const tripsRouter = require('./routes/trips');
const maintenanceRouter = require('./routes/maintenance');
const fuelLogsRouter = require('./routes/fuel-logs');
const expensesRouter = require('./routes/expenses');
const dashboardRouter = require('./routes/dashboard');
const reportsRouter = require('./routes/reports');
const settingsRouter = require('./routes/settings');

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors());
app.use(express.json());

// Mount routers under /api namespace
app.use('/api/vehicles', vehiclesRouter);
app.use('/api/drivers', driversRouter);
app.use('/api/trips', tripsRouter);
app.use('/api/maintenance', maintenanceRouter);
app.use('/api/fuel-logs', fuelLogsRouter);
app.use('/api/expenses', expensesRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/reports', reportsRouter);
app.use('/api/settings', settingsRouter);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', service: 'transitops-backend' });
});

// Start Server
app.listen(PORT, () => {
  console.log(`TransitOps backend core server is running on port ${PORT}`);
});
