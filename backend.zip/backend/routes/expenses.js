const express = require('express');
const router = express.Router();
const fuelExpensesController = require('../controllers/fuelExpensesController');
const verifyToken = require('../../authentication/middleware/verifyToken');

// Get all expenses
router.get('/', verifyToken, fuelExpensesController.getAllExpenses);

// Log general expense
router.post('/', verifyToken, fuelExpensesController.createExpense);

module.exports = router;
