const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/tripsController');
const verifyToken = require('../../authentication/middleware/verifyToken');
const requireRole = require('../../authentication/middleware/requireRole');

// Get all trips
router.get('/', verifyToken, tripsController.getAllTrips);

// Get trip by ID
router.get('/:id', verifyToken, tripsController.getTripById);

// Dispatch a new trip - Admin, Dispatcher, and Driver/Dispatcher
router.post('/', verifyToken, requireRole(['Admin', 'Dispatcher', 'Driver/Dispatcher']), tripsController.dispatchTrip);

// Complete a trip - Admin, Dispatcher, and Driver/Dispatcher
router.post('/:id/complete', verifyToken, requireRole(['Admin', 'Dispatcher', 'Driver/Dispatcher']), tripsController.completeTrip);

// Cancel a trip - Admin, Dispatcher, and Driver/Dispatcher
router.post('/:id/cancel', verifyToken, requireRole(['Admin', 'Dispatcher', 'Driver/Dispatcher']), tripsController.cancelTrip);

// Dispatch a draft trip - Admin, Dispatcher, and Driver/Dispatcher
router.post('/:id/dispatch', verifyToken, requireRole(['Admin', 'Dispatcher', 'Driver/Dispatcher']), tripsController.dispatchDraftTrip);

module.exports = router;
