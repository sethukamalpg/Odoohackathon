const express = require('express');
const router = express.Router();
const reportsController = require('../controllers/reportsController');
const verifyToken = require('../../authentication/middleware/verifyToken');
const requireRole = require('../../authentication/middleware/requireRole');

// Get all analytics report data - Admin, Manager, Fleet Manager, Financial Analyst
router.get('/analytics', verifyToken, requireRole(['Admin', 'Manager', 'Fleet Manager', 'Financial Analyst']), reportsController.getReportsData);

// Export CSV report - Admin, Manager, Fleet Manager, Financial Analyst
router.get('/export/:reportType', verifyToken, requireRole(['Admin', 'Manager', 'Fleet Manager', 'Financial Analyst']), reportsController.exportReport);

module.exports = router;
