const express = require('express');
const router = express.Router();
const pool = require('../db/pool');
const verifyToken = require('../../authentication/middleware/verifyToken');
const requireRole = require('../../authentication/middleware/requireRole');

// Get all users and their roles - Admin only
router.get('/users', verifyToken, requireRole(['Admin']), async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT u.id, u.name, u.email, u.created_at, r.name AS role, r.id AS role_id
      FROM users u
      JOIN roles r ON u.role_id = r.id
      ORDER BY u.id ASC
    `);
    return res.status(200).json(result.rows);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching users.' });
  }
});

// Update a user's role - Admin only
router.put('/users/:id/role', verifyToken, requireRole(['Admin']), async (req, res) => {
  const { role_id } = req.body;
  const userId = req.params.id;

  if (!role_id) {
    return res.status(400).json({ error: 'Please select a valid role.' });
  }

  // Prevent self-role-demotion of the active admin to avoid locking out the admin
  if (parseInt(userId) === req.user.id) {
    return res.status(400).json({ error: 'You cannot change your own role.' });
  }

  try {
    // Validate role exists
    const roleCheck = await pool.query('SELECT id FROM roles WHERE id = $1', [role_id]);
    if (roleCheck.rows.length === 0) {
      return res.status(400).json({ error: 'Selected role is invalid.' });
    }

    const result = await pool.query(
      'UPDATE users SET role_id = $1 WHERE id = $2 RETURNING id, name, email, role_id',
      [role_id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found.' });
    }

    return res.status(200).json({ message: 'User role updated successfully.', user: result.rows[0] });
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while updating the role.' });
  }
});

module.exports = router;
