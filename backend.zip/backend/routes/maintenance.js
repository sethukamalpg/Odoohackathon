const express = require('express');
const router = express.Router();
const maintenanceController = require('../controllers/maintenanceController');
const verifyToken = require('../../authentication/middleware/verifyToken');
const requireRole = require('../../authentication/middleware/requireRole');

// Get all maintenance records
router.get('/', verifyToken, maintenanceController.getAllMaintenanceLogs);

// Log a maintenance ticket - Admin, Dispatcher, Manager
router.post('/', verifyToken, requireRole(['Admin', 'Dispatcher', 'Manager']), maintenanceController.createMaintenanceLog);

// Close/Complete a maintenance ticket - Admin, Dispatcher, Manager
router.post('/:id/complete', verifyToken, requireRole(['Admin', 'Dispatcher', 'Manager']), maintenanceController.closeMaintenanceLog);

module.exports = router;
