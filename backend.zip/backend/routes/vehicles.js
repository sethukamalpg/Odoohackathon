const express = require('express');
const router = express.Router();
const vehiclesController = require('../controllers/vehiclesController');
const verifyToken = require('../../authentication/middleware/verifyToken');
const requireRole = require('../../authentication/middleware/requireRole');

// Get all vehicles - all authenticated users can view
router.get('/', verifyToken, vehiclesController.getAllVehicles);

// Get eligible vehicles for dispatch
router.get('/eligible', verifyToken, vehiclesController.getEligibleVehicles);

// Get vehicle by ID
router.get('/:id', verifyToken, vehiclesController.getVehicleById);

// Create new vehicle - Admin & Manager & Fleet Manager
router.post('/', verifyToken, requireRole(['Admin', 'Manager', 'Fleet Manager']), vehiclesController.createVehicle);

// Update vehicle - Admin & Manager & Fleet Manager
router.put('/:id', verifyToken, requireRole(['Admin', 'Manager', 'Fleet Manager']), vehiclesController.updateVehicle);

// Delete vehicle - Admin only
router.delete('/:id', verifyToken, requireRole(['Admin']), vehiclesController.deleteVehicle);

module.exports = router;
