const express = require('express');
const router = express.Router();
const reportsController = require('../controllers/reportsController');
const verifyToken = require('../../authentication/middleware/verifyToken');

// Get dashboard KPIs and distributions
router.get('/kpi', verifyToken, reportsController.getDashboardKPIs);

module.exports = router;
