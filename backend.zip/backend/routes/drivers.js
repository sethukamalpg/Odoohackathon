const express = require('express');
const router = Router = express.Router();
const driversController = require('../controllers/driversController');
const verifyToken = require('../../authentication/middleware/verifyToken');
const requireRole = require('../../authentication/middleware/requireRole');

// Get all drivers
router.get('/', verifyToken, driversController.getAllDrivers);

// Get eligible drivers for dispatch
router.get('/eligible', verifyToken, driversController.getEligibleDrivers);

// Get driver by ID
router.get('/:id', verifyToken, driversController.getDriverById);

// Create new driver - Admin, Manager, Fleet Manager, Safety Officer
router.post('/', verifyToken, requireRole(['Admin', 'Manager', 'Fleet Manager', 'Safety Officer']), driversController.createDriver);

// Update driver - Admin, Manager, Fleet Manager, Safety Officer
router.put('/:id', verifyToken, requireRole(['Admin', 'Manager', 'Fleet Manager', 'Safety Officer']), driversController.updateDriver);

// Delete driver - Admin only
router.delete('/:id', verifyToken, requireRole(['Admin']), driversController.deleteDriver);

module.exports = router;
