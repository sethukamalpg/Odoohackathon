const express = require('express');
const router = express.Router();
const fuelExpensesController = require('../controllers/fuelExpensesController');
const verifyToken = require('../../authentication/middleware/verifyToken');

// Get all fuel logs
router.get('/', verifyToken, fuelExpensesController.getAllFuelLogs);

// Log fuel purchase
router.post('/', verifyToken, fuelExpensesController.createFuelLog);

module.exports = router;
