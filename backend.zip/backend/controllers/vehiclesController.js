const vehicleService = require('../services/vehicleService');

const getAllVehicles = async (req, res) => {
  try {
    const vehicles = await vehicleService.getAllVehicles();
    return res.status(200).json(vehicles);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching vehicles.' });
  }
};

const getVehicleById = async (req, res) => {
  try {
    const vehicle = await vehicleService.getVehicleById(req.params.id);
    if (!vehicle) {
      return res.status(404).json({ error: 'Vehicle not found.' });
    }
    return res.status(200).json(vehicle);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching the vehicle.' });
  }
};

const createVehicle = async (req, res) => {
  try {
    const { registration_number, model, type, max_load_capacity, acquisition_cost, odometer, region } = req.body;

    // Validation checks
    if (!registration_number || registration_number.trim() === '') {
      return res.status(400).json({ error: 'Please enter a valid vehicle registration number.' });
    }
    if (!model || model.trim() === '') {
      return res.status(400).json({ error: 'Please enter the vehicle model name.' });
    }
    if (!type || type.trim() === '') {
      return res.status(400).json({ error: 'Please select a vehicle type.' });
    }
    if (max_load_capacity === undefined || parseFloat(max_load_capacity) <= 0) {
      return res.status(400).json({ error: 'Please enter a valid load capacity greater than 0.' });
    }
    if (acquisition_cost === undefined || parseFloat(acquisition_cost) < 0) {
      return res.status(400).json({ error: 'Please enter a valid acquisition cost.' });
    }
    if (odometer !== undefined && parseFloat(odometer) < 0) {
      return res.status(400).json({ error: 'Odometer reading cannot be negative.' });
    }
    if (region && !['North', 'South', 'East', 'West'].includes(region)) {
      return res.status(400).json({ error: 'Please select a valid operating region (North, South, East, West).' });
    }

    const newVehicle = await vehicleService.createVehicle(req.body);
    return res.status(201).json({ message: 'Vehicle added successfully.', vehicle: newVehicle });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while creating the vehicle.' });
  }
};

const updateVehicle = async (req, res) => {
  try {
    const { registration_number, model, type, status, max_load_capacity, acquisition_cost, odometer, region } = req.body;

    // Validation checks
    if (!registration_number || registration_number.trim() === '') {
      return res.status(400).json({ error: 'Please enter a valid vehicle registration number.' });
    }
    if (!model || model.trim() === '') {
      return res.status(400).json({ error: 'Please enter the vehicle model name.' });
    }
    if (!type || type.trim() === '') {
      return res.status(400).json({ error: 'Please select a vehicle type.' });
    }
    if (!status || status.trim() === '') {
      return res.status(400).json({ error: 'Please select a vehicle status.' });
    }
    if (max_load_capacity === undefined || parseFloat(max_load_capacity) <= 0) {
      return res.status(400).json({ error: 'Please enter a valid load capacity greater than 0.' });
    }
    if (acquisition_cost === undefined || parseFloat(acquisition_cost) < 0) {
      return res.status(400).json({ error: 'Please enter a valid acquisition cost.' });
    }
    if (odometer !== undefined && parseFloat(odometer) < 0) {
      return res.status(400).json({ error: 'Odometer reading cannot be negative.' });
    }
    if (region && !['North', 'South', 'East', 'West'].includes(region)) {
      return res.status(400).json({ error: 'Please select a valid operating region (North, South, East, West).' });
    }

    const updatedVehicle = await vehicleService.updateVehicle(req.params.id, req.body);
    return res.status(200).json({ message: 'Vehicle updated successfully.', vehicle: updatedVehicle });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while updating the vehicle.' });
  }
};

const deleteVehicle = async (req, res) => {
  try {
    await vehicleService.deleteVehicle(req.params.id);
    return res.status(200).json({ message: 'Vehicle deleted successfully.' });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while deleting the vehicle.' });
  }
};

const getEligibleVehicles = async (req, res) => {
  try {
    const eligible = await vehicleService.getEligibleVehicles();
    return res.status(200).json(eligible);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching eligible vehicles.' });
  }
};

module.exports = {
  getAllVehicles,
  getVehicleById,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  getEligibleVehicles,
};
