const analyticsService = require('../services/analyticsService');

const getDashboardKPIs = async (req, res) => {
  try {
    const kpis = await analyticsService.getDashboardKPIs(req.query);
    return res.status(200).json(kpis);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching dashboard data.' });
  }
};

const getReportsData = async (req, res) => {
  try {
    const reports = await analyticsService.getReportsData();
    return res.status(200).json(reports);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching reports.' });
  }
};

const exportReport = async (req, res) => {
  const { reportType } = req.params;
  try {
    const reports = await analyticsService.getReportsData();
    let dataToExport = [];
    let filename = 'report.csv';

    switch (reportType) {
      case 'roi':
        dataToExport = reports.roi;
        filename = 'vehicle_roi_report.csv';
        break;
      case 'costs':
        dataToExport = reports.costs;
        filename = 'operational_costs_report.csv';
        break;
      case 'fuel':
        dataToExport = reports.fuel;
        filename = 'fuel_efficiency_report.csv';
        break;
      case 'utilization':
        dataToExport = reports.utilization;
        filename = 'fleet_utilization_report.csv';
        break;
      default:
        return res.status(400).json({ error: 'Invalid report type requested for export.' });
    }

    const csvContent = analyticsService.convertToCSV(dataToExport);
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
    return res.status(200).send(csvContent);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while exporting report.' });
  }
};

module.exports = {
  getDashboardKPIs,
  getReportsData,
  exportReport,
};
