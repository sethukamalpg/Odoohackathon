const fuelExpenseService = require('../services/fuelExpenseService');

const getAllFuelLogs = async (req, res) => {
  try {
    const logs = await fuelExpenseService.getAllFuelLogs();
    return res.status(200).json(logs);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching fuel logs.' });
  }
};

const createFuelLog = async (req, res) => {
  try {
    const { vehicle_id, liters, cost } = req.body;

    if (!vehicle_id) {
      return res.status(400).json({ error: 'Please select a vehicle.' });
    }
    if (!liters || parseFloat(liters) <= 0) {
      return res.status(400).json({ error: 'Please enter a valid amount of liters.' });
    }
    if (!cost || parseFloat(cost) < 0) {
      return res.status(400).json({ error: 'Please enter a valid fuel cost.' });
    }

    const log = await fuelExpenseService.createFuelLog(req.body);
    return res.status(201).json({ message: 'Fuel purchase logged successfully.', log });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while creating fuel log.' });
  }
};

const getAllExpenses = async (req, res) => {
  try {
    const expenses = await fuelExpenseService.getAllExpenses();
    return res.status(200).json(expenses);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching expenses.' });
  }
};

const createExpense = async (req, res) => {
  try {
    const { vehicle_id, category, amount, description } = req.body;

    if (!vehicle_id) {
      return res.status(400).json({ error: 'Please select a vehicle.' });
    }
    if (!category) {
      return res.status(400).json({ error: 'Please select an expense category.' });
    }
    if (amount === undefined || parseFloat(amount) < 0) {
      return res.status(400).json({ error: 'Please enter a valid expense amount.' });
    }

    const expense = await fuelExpenseService.createExpense(req.body);
    return res.status(201).json({ message: 'Expense logged successfully.', expense });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while creating expense.' });
  }
};

module.exports = {
  getAllFuelLogs,
  createFuelLog,
  getAllExpenses,
  createExpense,
};
