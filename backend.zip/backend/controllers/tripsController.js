const tripService = require('../services/tripService');

const getAllTrips = async (req, res) => {
  try {
    const trips = await tripService.getAllTrips();
    return res.status(200).json(trips);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching trips.' });
  }
};

const getTripById = async (req, res) => {
  try {
    const trip = await tripService.getTripById(req.params.id);
    if (!trip) {
      return res.status(404).json({ error: 'Trip not found.' });
    }
    return res.status(200).json(trip);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching the trip.' });
  }
};

const dispatchTrip = async (req, res) => {
  try {
    const { trip_number, vehicle_id, driver_id, source, destination, cargo_weight, planned_distance, status } = req.body;

    // Direct input validations
    if (!trip_number || trip_number.trim() === '') {
      return res.status(400).json({ error: 'Please enter a valid trip reference number.' });
    }
    if (!vehicle_id) {
      return res.status(400).json({ error: 'Please select a vehicle for this trip.' });
    }
    if (!driver_id) {
      return res.status(400).json({ error: 'Please assign a driver for this trip.' });
    }
    if (!source || source.trim() === '') {
      return res.status(400).json({ error: 'Please enter the starting dispatch location.' });
    }
    if (!destination || destination.trim() === '') {
      return res.status(400).json({ error: 'Please enter the delivery destination.' });
    }
    if (cargo_weight === undefined || parseFloat(cargo_weight) <= 0) {
      return res.status(400).json({ error: 'Please enter a cargo weight greater than 0.' });
    }
    if (planned_distance !== undefined && parseFloat(planned_distance) < 0) {
      return res.status(400).json({ error: 'Planned distance cannot be negative.' });
    }

    const trip = await tripService.dispatchTrip(req.body);
    return res.status(201).json({ message: 'Trip dispatched successfully.', trip });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while dispatching the trip.' });
  }
};

const completeTrip = async (req, res) => {
  try {
    const { revenue, final_odometer, fuel_consumed } = req.body;
    
    if (revenue === undefined || parseFloat(revenue) < 0) {
      return res.status(400).json({ error: 'Please enter a valid non-negative revenue amount.' });
    }
    if (final_odometer !== undefined && parseFloat(final_odometer) < 0) {
      return res.status(400).json({ error: 'Final odometer reading cannot be negative.' });
    }
    if (fuel_consumed !== undefined && parseFloat(fuel_consumed) < 0) {
      return res.status(400).json({ error: 'Fuel consumed cannot be negative.' });
    }

    const trip = await tripService.completeTrip(req.params.id, req.body);
    return res.status(200).json({ message: 'Trip marked as completed.', trip });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while completing the trip.' });
  }
};

const cancelTrip = async (req, res) => {
  try {
    const trip = await tripService.cancelTrip(req.params.id);
    return res.status(200).json({ message: 'Trip successfully cancelled.', trip });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while cancelling the trip.' });
  }
};

const dispatchDraftTrip = async (req, res) => {
  try {
    const trip = await tripService.dispatchDraftTrip(req.params.id);
    return res.status(200).json({ message: 'Draft trip successfully dispatched.', trip });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while dispatching the draft trip.' });
  }
};

module.exports = {
  getAllTrips,
  getTripById,
  dispatchTrip,
  completeTrip,
  cancelTrip,
  dispatchDraftTrip,
};
