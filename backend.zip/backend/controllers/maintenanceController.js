const maintenanceService = require('../services/maintenanceService');

const getAllMaintenanceLogs = async (req, res) => {
  try {
    const logs = await maintenanceService.getAllMaintenanceLogs();
    return res.status(200).json(logs);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching maintenance logs.' });
  }
};

const createMaintenanceLog = async (req, res) => {
  try {
    const { vehicle_id, description, cost, status } = req.body;

    if (!vehicle_id) {
      return res.status(400).json({ error: 'Please select a vehicle for maintenance.' });
    }
    if (!description || description.trim() === '') {
      return res.status(400).json({ error: 'Please enter a description for the maintenance work.' });
    }
    if (cost !== undefined && parseFloat(cost) < 0) {
      return res.status(400).json({ error: 'Please enter a valid maintenance cost.' });
    }

    const log = await maintenanceService.createMaintenanceLog(req.body);
    return res.status(201).json({ message: 'Maintenance record created successfully.', log });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while creating maintenance record.' });
  }
};

const closeMaintenanceLog = async (req, res) => {
  try {
    const { cost } = req.body;

    if (cost === undefined || parseFloat(cost) < 0) {
      return res.status(400).json({ error: 'Please enter a valid cost to close this maintenance record.' });
    }

    const log = await maintenanceService.closeMaintenanceLog(req.params.id, req.body);
    return res.status(200).json({ message: 'Maintenance record closed successfully.', log });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while closing maintenance record.' });
  }
};

module.exports = {
  getAllMaintenanceLogs,
  createMaintenanceLog,
  closeMaintenanceLog,
};
