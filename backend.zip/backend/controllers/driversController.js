const driverService = require('../services/driverService');

const getAllDrivers = async (req, res) => {
  try {
    const drivers = await driverService.getAllDrivers();
    return res.status(200).json(drivers);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching drivers.' });
  }
};

const getDriverById = async (req, res) => {
  try {
    const driver = await driverService.getDriverById(req.params.id);
    if (!driver) {
      return res.status(404).json({ error: 'Driver not found.' });
    }
    return res.status(200).json(driver);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching the driver.' });
  }
};

const createDriver = async (req, res) => {
  try {
    const { name, license_number, license_expiry_date, safety_score } = req.body;

    if (!name || name.trim() === '') {
      return res.status(400).json({ error: 'Please enter the driver name.' });
    }
    if (!license_number || license_number.trim() === '') {
      return res.status(400).json({ error: 'Please enter a valid driver license number.' });
    }
    if (!license_expiry_date) {
      return res.status(400).json({ error: 'Please enter the driver license expiry date.' });
    }
    const score = parseInt(safety_score);
    if (isNaN(score) || score < 0 || score > 100) {
      return res.status(400).json({ error: 'Safety score must be an integer between 0 and 100.' });
    }

    const newDriver = await driverService.createDriver(req.body);
    return res.status(201).json({ message: 'Driver created successfully.', driver: newDriver });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while creating the driver.' });
  }
};

const updateDriver = async (req, res) => {
  try {
    const { name, license_number, license_expiry_date, status, safety_score } = req.body;

    if (!name || name.trim() === '') {
      return res.status(400).json({ error: 'Please enter the driver name.' });
    }
    if (!license_number || license_number.trim() === '') {
      return res.status(400).json({ error: 'Please enter a valid driver license number.' });
    }
    if (!license_expiry_date) {
      return res.status(400).json({ error: 'Please enter the driver license expiry date.' });
    }
    if (!status) {
      return res.status(400).json({ error: 'Please select a driver status.' });
    }
    const score = parseInt(safety_score);
    if (isNaN(score) || score < 0 || score > 100) {
      return res.status(400).json({ error: 'Safety score must be an integer between 0 and 100.' });
    }

    const updatedDriver = await driverService.updateDriver(req.params.id, req.body);
    return res.status(200).json({ message: 'Driver updated successfully.', driver: updatedDriver });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while updating the driver.' });
  }
};

const deleteDriver = async (req, res) => {
  try {
    await driverService.deleteDriver(req.params.id);
    return res.status(200).json({ message: 'Driver deleted successfully.' });
  } catch (error) {
    const status = error.status || 500;
    return res.status(status).json({ error: error.message || 'An error occurred while deleting the driver.' });
  }
};

const getEligibleDrivers = async (req, res) => {
  try {
    const eligible = await driverService.getEligibleDrivers();
    return res.status(200).json(eligible);
  } catch (error) {
    return res.status(500).json({ error: error.message || 'An error occurred while fetching eligible drivers.' });
  }
};

module.exports = {
  getAllDrivers,
  getDriverById,
  createDriver,
  updateDriver,
  deleteDriver,
  getEligibleDrivers,
};
