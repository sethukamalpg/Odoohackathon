const { pool } = require('../db/pool');

/**
 * Get all trips.
 */
const getAllTrips = async () => {
  const result = await pool.query(
    `SELECT t.*, v.registration_number, v.model AS vehicle_model, v.odometer AS vehicle_odometer, d.name AS driver_name 
     FROM trips t
     JOIN vehicles v ON t.vehicle_id = v.id
     JOIN drivers d ON t.driver_id = d.id
     ORDER BY t.id DESC`
  );
  return result.rows;
};

/**
 * Get trip by ID.
 */
const getTripById = async (id) => {
  const result = await pool.query(
    `SELECT t.*, v.registration_number, v.model AS vehicle_model, v.odometer AS vehicle_odometer, d.name AS driver_name 
     FROM trips t
     JOIN vehicles v ON t.vehicle_id = v.id
     JOIN drivers d ON t.driver_id = d.id
     WHERE t.id = $1`,
    [id]
  );
  return result.rows[0];
};

/**
 * Dispatch a trip. Performs state validations and locks resources within a database transaction.
 */
const dispatchTrip = async (tripData) => {
  const { trip_number, vehicle_id, driver_id, source, destination, cargo_weight, planned_distance, status } = tripData;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Validate vehicle
    const vehicleRes = await client.query('SELECT status, max_load_capacity FROM vehicles WHERE id = $1 FOR UPDATE', [vehicle_id]);
    if (vehicleRes.rows.length === 0) {
      throw new Error('Selected vehicle does not exist.');
    }
    const vehicle = vehicleRes.rows[0];
    if (vehicle.status !== 'Available') {
      throw new Error(`Vehicle is not available for dispatch. Current status: ${vehicle.status}.`);
    }

    // 2. Validate driver
    const driverRes = await client.query('SELECT status, license_expiry_date FROM drivers WHERE id = $1 FOR UPDATE', [driver_id]);
    if (driverRes.rows.length === 0) {
      throw new Error('Selected driver does not exist.');
    }
    const driver = driverRes.rows[0];
    if (driver.status !== 'Available') {
      throw new Error(`Driver is not available for dispatch. Current status: ${driver.status}.`);
    }

    const today = new Date();
    const expiry = new Date(driver.license_expiry_date);
    if (expiry <= today) {
      throw new Error('Cannot dispatch: The selected driver has an expired license.');
    }

    // 3. Cargo weight check
    if (parseFloat(cargo_weight) > parseFloat(vehicle.max_load_capacity)) {
      throw new Error(`Cargo weight (${cargo_weight} lbs) exceeds the vehicle's maximum load capacity (${vehicle.max_load_capacity} lbs).`);
    }

    // 4. Duplicate trip number check
    const tripNumCheck = await client.query('SELECT id FROM trips WHERE trip_number = $1', [trip_number]);
    if (tripNumCheck.rows.length > 0) {
      throw new Error(`Trip number '${trip_number}' already exists.`);
    }

    // 5. Insert trip (Default to Dispatched unless requested as Draft)
    const tripStatus = status || 'Dispatched';
    const tripResult = await client.query(
      `INSERT INTO trips (trip_number, vehicle_id, driver_id, source, destination, status, cargo_weight, planned_distance, revenue, start_date)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 0.00, CURRENT_TIMESTAMP)
       RETURNING *`,
      [trip_number, vehicle_id, driver_id, source, destination, tripStatus, cargo_weight, planned_distance || 0.00]
    );

    // If dispatched immediately, lock vehicle & driver
    if (tripStatus === 'Dispatched') {
      await client.query("UPDATE vehicles SET status = 'On Trip' WHERE id = $1", [vehicle_id]);
      await client.query("UPDATE drivers SET status = 'On Trip' WHERE id = $1", [driver_id]);
    }

    await client.query('COMMIT');
    return tripResult.rows[0];
  } catch (error) {
    await client.query('ROLLBACK');
    error.status = error.status || 400;
    throw error;
  } finally {
    client.release();
  }
};

/**
 * Complete an ongoing trip. Releases vehicle and driver back to 'Available'.
 * Saves final odometer and fuel consumed.
 */
const completeTrip = async (tripId, completionData) => {
  const { revenue, final_odometer, fuel_consumed } = completionData;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Get trip details
    const tripRes = await client.query('SELECT * FROM trips WHERE id = $1 FOR UPDATE', [tripId]);
    if (tripRes.rows.length === 0) {
      throw new Error('Trip not found.');
    }
    const trip = tripRes.rows[0];
    if (trip.status !== 'Dispatched') {
      throw new Error(`Only dispatched trips can be completed. Current status: ${trip.status}.`);
    }

    if (revenue === undefined || revenue === null || parseFloat(revenue) < 0) {
      throw new Error('Please enter a valid non-negative revenue amount.');
    }

    // Update trip
    const tripResult = await client.query(
      `UPDATE trips 
       SET status = 'Completed', end_date = CURRENT_TIMESTAMP, revenue = $1 
       WHERE id = $2 
       RETURNING *`,
      [revenue, tripId]
    );

    // Save final odometer to the vehicle
    if (final_odometer !== undefined && final_odometer !== null && parseFloat(final_odometer) >= 0) {
      await client.query("UPDATE vehicles SET odometer = $1 WHERE id = $2", [parseFloat(final_odometer), trip.vehicle_id]);
    }

    // Save fuel consumed as a fuel log
    if (fuel_consumed !== undefined && fuel_consumed !== null && parseFloat(fuel_consumed) > 0) {
      const fuelCost = parseFloat(fuel_consumed) * 1.15; // default fuel price estimate
      await client.query(
        `INSERT INTO fuel_logs (vehicle_id, liters, cost, logged_at) 
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
        [trip.vehicle_id, parseFloat(fuel_consumed), fuelCost]
      );
    }

    // Release vehicle (unless retired)
    const vehRes = await client.query('SELECT status FROM vehicles WHERE id = $1', [trip.vehicle_id]);
    if (vehRes.rows.length > 0 && vehRes.rows[0].status !== 'Retired') {
      await client.query("UPDATE vehicles SET status = 'Available' WHERE id = $1", [trip.vehicle_id]);
    }

    // Release driver (unless suspended)
    const drvRes = await client.query('SELECT status FROM drivers WHERE id = $1', [trip.driver_id]);
    if (drvRes.rows.length > 0 && drvRes.rows[0].status !== 'Suspended') {
      await client.query("UPDATE drivers SET status = 'Available' WHERE id = $1", [trip.driver_id]);
    }

    await client.query('COMMIT');
    return tripResult.rows[0];
  } catch (error) {
    await client.query('ROLLBACK');
    error.status = error.status || 400;
    throw error;
  } finally {
    client.release();
  }
};

/**
 * Cancel a dispatched trip. Restores vehicle and driver status.
 */
const cancelTrip = async (tripId) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Get trip details
    const tripRes = await client.query('SELECT * FROM trips WHERE id = $1 FOR UPDATE', [tripId]);
    if (tripRes.rows.length === 0) {
      throw new Error('Trip not found.');
    }
    const trip = tripRes.rows[0];
    if (trip.status !== 'Dispatched') {
      throw new Error(`Only dispatched trips can be cancelled. Current status: ${trip.status}.`);
    }

    // Update trip status to 'Cancelled'
    const tripResult = await client.query(
      `UPDATE trips 
       SET status = 'Cancelled', end_date = CURRENT_TIMESTAMP 
       WHERE id = $1 
       RETURNING *`,
      [tripId]
    );

    // Release vehicle
    const vehRes = await client.query('SELECT status FROM vehicles WHERE id = $1', [trip.vehicle_id]);
    if (vehRes.rows.length > 0 && vehRes.rows[0].status !== 'Retired') {
      await client.query("UPDATE vehicles SET status = 'Available' WHERE id = $1", [trip.vehicle_id]);
    }

    // Release driver
    const drvRes = await client.query('SELECT status FROM drivers WHERE id = $1', [trip.driver_id]);
    if (drvRes.rows.length > 0 && drvRes.rows[0].status !== 'Suspended') {
      await client.query("UPDATE drivers SET status = 'Available' WHERE id = $1", [trip.driver_id]);
    }

    await client.query('COMMIT');
    return tripResult.rows[0];
  } catch (error) {
    await client.query('ROLLBACK');
    error.status = error.status || 400;
    throw error;
  } finally {
    client.release();
  }
};

/**
 * Dispatches a trip that was previously saved as Draft. Locks vehicle and driver.
 */
const dispatchDraftTrip = async (tripId) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Get trip details
    const tripRes = await client.query('SELECT * FROM trips WHERE id = $1 FOR UPDATE', [tripId]);
    if (tripRes.rows.length === 0) {
      throw new Error('Trip not found.');
    }
    const trip = tripRes.rows[0];
    if (trip.status !== 'Draft') {
      throw new Error(`Only draft trips can be dispatched. Current status: ${trip.status}.`);
    }

    // Validate vehicle is still Available
    const vehicleRes = await client.query('SELECT status FROM vehicles WHERE id = $1 FOR UPDATE', [trip.vehicle_id]);
    if (vehicleRes.rows.length === 0) {
      throw new Error('Associated vehicle not found.');
    }
    if (vehicleRes.rows[0].status !== 'Available') {
      throw new Error(`Associated vehicle is not available. Status: ${vehicleRes.rows[0].status}`);
    }

    // Validate driver is still Available
    const driverRes = await client.query('SELECT status FROM drivers WHERE id = $1 FOR UPDATE', [trip.driver_id]);
    if (driverRes.rows.length === 0) {
      throw new Error('Associated driver not found.');
    }
    if (driverRes.rows[0].status !== 'Available') {
      throw new Error(`Associated driver is not available. Status: ${driverRes.rows[0].status}`);
    }

    // Update trip status to Dispatched
    const tripResult = await client.query(
      "UPDATE trips SET status = 'Dispatched' WHERE id = $1 RETURNING *",
      [tripId]
    );

    // Lock vehicle & driver
    await client.query("UPDATE vehicles SET status = 'On Trip' WHERE id = $1", [trip.vehicle_id]);
    await client.query("UPDATE drivers SET status = 'On Trip' WHERE id = $1", [trip.driver_id]);

    await client.query('COMMIT');
    return tripResult.rows[0];
  } catch (error) {
    await client.query('ROLLBACK');
    error.status = error.status || 400;
    throw error;
  } finally {
    client.release();
  }
};

module.exports = {
  getAllTrips,
  getTripById,
  dispatchTrip,
  completeTrip,
  cancelTrip,
  dispatchDraftTrip,
};
