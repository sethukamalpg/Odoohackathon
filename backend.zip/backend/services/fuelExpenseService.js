const pool = require('../db/pool');

/**
 * Get all fuel logs.
 */
const getAllFuelLogs = async () => {
  const result = await pool.query(
    `SELECT f.*, v.registration_number, v.model AS vehicle_model 
     FROM fuel_logs f
     JOIN vehicles v ON f.vehicle_id = v.id
     ORDER BY f.id DESC`
  );
  return result.rows;
};

/**
 * Create a new fuel log and update vehicle's current fuel level if necessary.
 */
const createFuelLog = async (fuelData) => {
  const { vehicle_id, liters, cost } = fuelData;

  if (!vehicle_id) {
    const err = new Error('Please select a vehicle.');
    err.status = 400;
    throw err;
  }
  if (!liters || parseFloat(liters) <= 0) {
    const err = new Error('Please enter a valid amount of liters.');
    err.status = 400;
    throw err;
  }
  if (!cost || parseFloat(cost) < 0) {
    const err = new Error('Please enter a valid cost.');
    err.status = 400;
    throw err;
  }

  const client = await pool.pool.connect();
  try {
    await client.query('BEGIN');

    // Check if vehicle exists
    const vehCheck = await client.query('SELECT id FROM vehicles WHERE id = $1', [vehicle_id]);
    if (vehCheck.rows.length === 0) {
      throw new Error('Selected vehicle does not exist.');
    }

    const result = await client.query(
      `INSERT INTO fuel_logs (vehicle_id, liters, cost, logged_at)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
       RETURNING *`,
      [vehicle_id, liters, cost]
    );

    // Refuel vehicle - set fuel level to 100% on a fuel up
    await client.query("UPDATE vehicles SET current_fuel_level = 100.00 WHERE id = $1", [vehicle_id]);

    await client.query('COMMIT');
    return result.rows[0];
  } catch (error) {
    await client.query('ROLLBACK');
    error.status = error.status || 400;
    throw error;
  } finally {
    client.release();
  }
};

/**
 * Get all general expenses.
 */
const getAllExpenses = async () => {
  const result = await pool.query(
    `SELECT e.*, v.registration_number, v.model AS vehicle_model 
     FROM expenses e
     JOIN vehicles v ON e.vehicle_id = v.id
     ORDER BY e.id DESC`
  );
  return result.rows;
};

/**
 * Create a new general expense.
 */
const createExpense = async (expenseData) => {
  const { vehicle_id, category, amount, description } = expenseData;

  if (!vehicle_id) {
    const err = new Error('Please select a vehicle.');
    err.status = 400;
    throw err;
  }
  if (!category) {
    const err = new Error('Please select an expense category.');
    err.status = 400;
    throw err;
  }
  if (amount === undefined || parseFloat(amount) < 0) {
    const err = new Error('Please enter a valid expense amount.');
    err.status = 400;
    throw err;
  }

  // Validate vehicle exists
  const vehCheck = await pool.query('SELECT id FROM vehicles WHERE id = $1', [vehicle_id]);
  if (vehCheck.rows.length === 0) {
    const err = new Error('Selected vehicle does not exist.');
    err.status = 400;
    throw err;
  }

  const result = await pool.query(
    `INSERT INTO expenses (vehicle_id, category, amount, description, logged_at)
     VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
     RETURNING *`,
    [vehicle_id, category, amount, description]
  );

  return result.rows[0];
};

module.exports = {
  getAllFuelLogs,
  createFuelLog,
  getAllExpenses,
  createExpense,
};
