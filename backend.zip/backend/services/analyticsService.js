const pool = require('../db/pool');

/**
 * Get core KPIs and recent activity for the Dashboard view.
 */
const getDashboardKPIs = async (filters = {}) => {
  const { vehicleType, status, region } = filters;
  
  // Build dynamic where clause for vehicles
  let vehWhereClauses = [];
  let vehParams = [];
  let paramIdx = 1;

  if (vehicleType) {
    vehWhereClauses.push(`type = $${paramIdx}`);
    vehParams.push(vehicleType);
    paramIdx++;
  }
  if (status) {
    vehWhereClauses.push(`status = $${paramIdx}`);
    vehParams.push(status);
    paramIdx++;
  }
  if (region) {
    vehWhereClauses.push(`region = $${paramIdx}`);
    vehParams.push(region);
    paramIdx++;
  }

  const vehWhereStr = vehWhereClauses.length > 0 ? 'WHERE ' + vehWhereClauses.join(' AND ') : '';

  // 1. Total Vehicles vs Active/Non-Retired Vehicles
  const vehRes = await pool.query(`
    SELECT 
      COUNT(*) AS total_count,
      COUNT(CASE WHEN status != 'Retired' THEN 1 END) AS active_count,
      COUNT(CASE WHEN status = 'On Trip' THEN 1 END) AS on_trip_count,
      COUNT(CASE WHEN status = 'In Shop' THEN 1 END) AS in_shop_count,
      COUNT(CASE WHEN status = 'Available' THEN 1 END) AS available_count
    FROM vehicles
    ${vehWhereStr}
  `, vehParams);
  const vehStats = vehRes.rows[0];

  // 2. Active Trips (Dispatched status) & Pending (Draft)
  let tripVehJoin = '';
  let tripWhereClauses = [];
  let tripParams = [];
  let tripParamIdx = 1;

  if (vehicleType || region) {
    tripVehJoin = ' JOIN vehicles v ON t.vehicle_id = v.id ';
    if (vehicleType) {
      tripWhereClauses.push(`v.type = $${tripParamIdx}`);
      tripParams.push(vehicleType);
      tripParamIdx++;
    }
    if (region) {
      tripWhereClauses.push(`v.region = $${tripParamIdx}`);
      tripParams.push(region);
      tripParamIdx++;
    }
  }

  const activeTripsWhere = ['t.status = \'Dispatched\'', ...tripWhereClauses].join(' AND ');
  const tripsRes = await pool.query(`
    SELECT COUNT(*) AS active_trips 
    FROM trips t
    ${tripVehJoin}
    WHERE ${activeTripsWhere}
  `, tripParams);
  const activeTripsCount = parseInt(tripsRes.rows[0].active_trips || '0');

  const pendingTripsWhere = ['t.status = \'Draft\'', ...tripWhereClauses].join(' AND ');
  const pendingRes = await pool.query(`
    SELECT COUNT(*) AS pending_trips 
    FROM trips t
    ${tripVehJoin}
    WHERE ${pendingTripsWhere}
  `, tripParams);
  const pendingTripsCount = parseInt(pendingRes.rows[0].pending_trips || '0');

  // 3. Drivers On Duty
  const driversRes = await pool.query("SELECT COUNT(*) AS drivers_on_duty FROM drivers WHERE status = 'On Trip'");
  const driversOnDuty = parseInt(driversRes.rows[0].drivers_on_duty || '0');

  // 4. Total Maintenance Costs
  const maintRes = await pool.query("SELECT COALESCE(SUM(cost), 0) AS total_maint_cost FROM maintenance_logs");
  const totalMaintCost = parseFloat(maintRes.rows[0].total_maint_cost || '0');

  // 5. Total Revenue
  const revRes = await pool.query("SELECT COALESCE(SUM(revenue), 0) AS total_revenue FROM trips WHERE status = 'Completed'");
  const totalRevenue = parseFloat(revRes.rows[0].total_revenue || '0');

  // 6. Fleet Utilization Rate
  const activeVehCount = parseInt(vehStats.active_count || '0');
  const onTripVehCount = parseInt(vehStats.on_trip_count || '0');
  const utilizationRate = activeVehCount > 0 ? ((onTripVehCount / activeVehCount) * 100) : 0;

  // 7. Recent Trips (Last 5 trips)
  const recentTripsRes = await pool.query(`
    SELECT t.*, v.registration_number, v.model AS vehicle_model, d.name AS driver_name 
    FROM trips t
    JOIN vehicles v ON t.vehicle_id = v.id
    JOIN drivers d ON t.driver_id = d.id
    ORDER BY t.id DESC
    LIMIT 5
  `);

  // 8. Fleet Status Chart Data (Distribution)
  const fleetDistribution = [
    { name: 'Available', value: parseInt(vehStats.available_count || '0') },
    { name: 'On Trip', value: parseInt(vehStats.on_trip_count || '0') },
    { name: 'In Shop', value: parseInt(vehStats.in_shop_count || '0') },
    { name: 'Retired', value: parseInt(vehStats.total_count || '0') - activeVehCount },
  ];

  return {
    kpis: {
      totalVehicles: parseInt(vehStats.total_count || '0'),
      activeVehicles: activeVehCount,
      availableVehicles: parseInt(vehStats.available_count || '0'),
      vehiclesInMaintenance: parseInt(vehStats.in_shop_count || '0'),
      activeTrips: activeTripsCount,
      pendingTrips: pendingTripsCount,
      driversOnDuty: driversOnDuty,
      totalMaintenanceCost: totalMaintCost,
      totalRevenue: totalRevenue,
      utilizationRate: Math.round(utilizationRate * 10) / 10,
    },
    recentTrips: recentTripsRes.rows,
    fleetDistribution,
  };
};

/**
 * Get detailed analytical reports data for the Reports page.
 */
const getReportsData = async () => {
  // 1. Vehicle ROI Analysis (server-side calculated)
  // ROI = (Revenue - (Maintenance + Fuel + Expenses)) / Acquisition Cost
  const roiRes = await pool.query(`
    SELECT 
      v.id,
      v.registration_number,
      v.model,
      v.acquisition_cost,
      COALESCE(t.total_revenue, 0) AS total_revenue,
      COALESCE(m.total_maint, 0) AS total_maintenance,
      COALESCE(f.total_fuel_cost, 0) AS total_fuel,
      COALESCE(e.total_expenses, 0) AS total_expenses,
      (
        COALESCE(t.total_revenue, 0) - (
          COALESCE(m.total_maint, 0) +
          COALESCE(f.total_fuel_cost, 0) +
          COALESCE(e.total_expenses, 0)
        )
      ) AS net_profit,
      CASE 
        WHEN v.acquisition_cost > 0 THEN 
          ROUND(((COALESCE(t.total_revenue, 0) - (COALESCE(m.total_maint, 0) + COALESCE(f.total_fuel_cost, 0) + COALESCE(e.total_expenses, 0))) / v.acquisition_cost) * 100, 2)
        ELSE 0.00
      END AS roi_percentage
    FROM vehicles v
    LEFT JOIN (
      SELECT vehicle_id, SUM(revenue) AS total_revenue 
      FROM trips 
      WHERE status = 'Completed'
      GROUP BY vehicle_id
    ) t ON t.vehicle_id = v.id
    LEFT JOIN (
      SELECT vehicle_id, SUM(cost) AS total_maint 
      FROM maintenance_logs 
      GROUP BY vehicle_id
    ) m ON m.vehicle_id = v.id
    LEFT JOIN (
      SELECT vehicle_id, SUM(cost) AS total_fuel_cost 
      FROM fuel_logs 
      GROUP BY vehicle_id
    ) f ON f.vehicle_id = v.id
    LEFT JOIN (
      SELECT vehicle_id, SUM(amount) AS total_expenses 
      FROM expenses 
      GROUP BY vehicle_id
    ) e ON e.vehicle_id = v.id
    ORDER BY roi_percentage DESC
  `);

  // 2. Operational Cost breakdown per vehicle (Running costs = fuel + maintenance + other)
  const costBreakdownRes = await pool.query(`
    SELECT 
      v.registration_number,
      v.model,
      COALESCE(f.fuel_cost, 0) AS fuel_cost,
      COALESCE(m.maint_cost, 0) AS maintenance_cost,
      COALESCE(e.expense_cost, 0) AS other_expenses,
      (COALESCE(f.fuel_cost, 0) + COALESCE(m.maint_cost, 0) + COALESCE(e.expense_cost, 0)) AS total_operational_cost
    FROM vehicles v
    LEFT JOIN (SELECT vehicle_id, SUM(cost) AS fuel_cost FROM fuel_logs GROUP BY vehicle_id) f ON f.vehicle_id = v.id
    LEFT JOIN (SELECT vehicle_id, SUM(cost) AS maint_cost FROM maintenance_logs GROUP BY vehicle_id) m ON m.vehicle_id = v.id
    LEFT JOIN (SELECT vehicle_id, SUM(amount) AS expense_cost FROM expenses GROUP BY vehicle_id) e ON e.vehicle_id = v.id
    ORDER BY total_operational_cost DESC
  `);

  // 3. Fuel Efficiency Metrics (Distance / Fuel liters)
  const fuelEfficiencyRes = await pool.query(`
    SELECT 
      v.registration_number,
      v.model,
      COALESCE(fl.total_liters, 0) AS total_liters,
      COALESCE(fl.total_fuel_spent, 0) AS total_fuel_spent,
      COALESCE(t.total_distance, 0) AS total_distance,
      CASE 
        WHEN COALESCE(fl.total_liters, 0) > 0 THEN 
          ROUND(COALESCE(t.total_distance, 0) / COALESCE(fl.total_liters, 1), 2)
        ELSE 0.00
      END AS fuel_efficiency
    FROM vehicles v
    LEFT JOIN (
      SELECT vehicle_id, SUM(liters) AS total_liters, SUM(cost) AS total_fuel_spent 
      FROM fuel_logs 
      GROUP BY vehicle_id
    ) fl ON fl.vehicle_id = v.id
    LEFT JOIN (
      SELECT vehicle_id, SUM(planned_distance) AS total_distance 
      FROM trips 
      WHERE status = 'Completed'
      GROUP BY vehicle_id
    ) t ON t.vehicle_id = v.id
    ORDER BY total_fuel_spent DESC
  `);

  // 4. Fleet Utilization (Number of completed trips, total weight moved, average cargo weight)
  const utilizationRes = await pool.query(`
    SELECT 
      v.registration_number,
      v.model,
      COUNT(t.id) AS trips_completed,
      COALESCE(SUM(t.cargo_weight), 0) AS total_weight_moved,
      CASE 
        WHEN COUNT(t.id) > 0 THEN 
          ROUND(AVG(t.cargo_weight), 2)
        ELSE 0.00
      END AS average_cargo_weight
    FROM vehicles v
    LEFT JOIN trips t ON t.vehicle_id = v.id AND t.status = 'Completed'
    GROUP BY v.id
    ORDER BY trips_completed DESC
  `);

  // 5. Monthly Revenue Chart (Teal Accent) - Last 6 months
  const monthlyRevenueRes = await pool.query(`
    SELECT 
      TO_CHAR(end_date, 'YYYY-MM') AS month,
      SUM(revenue) AS revenue
    FROM trips
    WHERE status = 'Completed'
      AND end_date >= CURRENT_DATE - INTERVAL '6 months'
    GROUP BY TO_CHAR(end_date, 'YYYY-MM')
    ORDER BY month ASC
  `);

  return {
    roi: roiRes.rows,
    costs: costBreakdownRes.rows,
    fuel: fuelEfficiencyRes.rows,
    utilization: utilizationRes.rows,
    monthlyRevenue: monthlyRevenueRes.rows,
  };
};

/**
 * Format database arrays as CSV format strings.
 */
const convertToCSV = (dataArray) => {
  if (!dataArray || dataArray.length === 0) return '';
  const headers = Object.keys(dataArray[0]);
  const csvRows = [];
  
  // Add headers row
  csvRows.push(headers.join(','));

  // Add data rows
  for (const row of dataArray) {
    const values = headers.map(header => {
      const val = row[header];
      const escaped = ('' + val).replace(/"/g, '\\"');
      return `"${escaped}"`;
    });
    csvRows.push(values.join(','));
  }

  return csvRows.join('\n');
};

module.exports = {
  getDashboardKPIs,
  getReportsData,
  convertToCSV,
};
