const db = require('../db/pool');

/**
 * Get all vehicles from database.
 */
const getAllVehicles = async () => {
  const result = await db.query('SELECT * FROM vehicles ORDER BY id DESC');
  return result.rows;
};

/**
 * Get vehicle by ID.
 */
const getVehicleById = async (id) => {
  const result = await db.query('SELECT * FROM vehicles WHERE id = $1', [id]);
  return result.rows[0];
};

/**
 * Create a new vehicle.
 */
const createVehicle = async (vehicleData) => {
  const { registration_number, model, type, status, max_load_capacity, acquisition_cost, odometer, region, current_fuel_level } = vehicleData;

  // Live validation for unique registration number
  const duplicateCheck = await db.query('SELECT id FROM vehicles WHERE registration_number = $1', [registration_number]);
  if (duplicateCheck.rows.length > 0) {
    const err = new Error(`Vehicle registration number '${registration_number}' is already registered in the system.`);
    err.status = 400;
    throw err;
  }

  const result = await db.query(
    `INSERT INTO vehicles (registration_number, model, type, status, max_load_capacity, acquisition_cost, odometer, region, current_fuel_level)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`,
    [registration_number, model, type, status || 'Available', max_load_capacity, acquisition_cost, odometer || 0.00, region || 'North', current_fuel_level || 100.00]
  );

  return result.rows[0];
};

/**
 * Update an existing vehicle.
 */
const updateVehicle = async (id, vehicleData) => {
  const { registration_number, model, type, status, max_load_capacity, acquisition_cost, odometer, region, current_fuel_level } = vehicleData;

  // Check if vehicle exists
  const existing = await db.query('SELECT * FROM vehicles WHERE id = $1', [id]);
  if (existing.rows.length === 0) {
    const err = new Error('Vehicle not found.');
    err.status = 404;
    throw err;
  }

  // Check for duplicate registration number (excluding current ID)
  const duplicateCheck = await db.query(
    'SELECT id FROM vehicles WHERE registration_number = $1 AND id != $2',
    [registration_number, id]
  );
  if (duplicateCheck.rows.length > 0) {
    const err = new Error(`Vehicle registration number '${registration_number}' is already in use by another vehicle.`);
    err.status = 400;
    throw err;
  }

  const result = await db.query(
    `UPDATE vehicles 
     SET registration_number = $1, model = $2, type = $3, status = $4, max_load_capacity = $5, acquisition_cost = $6, odometer = $7, region = $8, current_fuel_level = $9
     WHERE id = $10
     RETURNING *`,
    [registration_number, model, type, status, max_load_capacity, acquisition_cost, odometer, region, current_fuel_level, id]
  );

  return result.rows[0];
};

/**
 * Delete a vehicle.
 */
const deleteVehicle = async (id) => {
  const existing = await db.query('SELECT * FROM vehicles WHERE id = $1', [id]);
  if (existing.rows.length === 0) {
    const err = new Error('Vehicle not found.');
    err.status = 404;
    throw err;
  }

  await db.query('DELETE FROM vehicles WHERE id = $1', [id]);
  return true;
};

/**
 * Get vehicles eligible for dispatch (status must be 'Available').
 */
const getEligibleVehicles = async () => {
  const result = await db.query("SELECT * FROM vehicles WHERE status = 'Available' ORDER BY registration_number ASC");
  return result.rows;
};

module.exports = {
  getAllVehicles,
  getVehicleById,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  getEligibleVehicles,
};
