const db = require('../db/pool');

/**
 * Get all drivers from database.
 */
const getAllDrivers = async () => {
  const result = await db.query('SELECT * FROM drivers ORDER BY id DESC');
  return result.rows;
};

/**
 * Get driver by ID.
 */
const getDriverById = async (id) => {
  const result = await db.query('SELECT * FROM drivers WHERE id = $1', [id]);
  return result.rows[0];
};

/**
 * Create a new driver.
 */
const createDriver = async (driverData) => {
  const { name, license_number, license_expiry_date, status, safety_score } = driverData;

  // Validation
  const duplicateCheck = await db.query('SELECT id FROM drivers WHERE license_number = $1', [license_number]);
  if (duplicateCheck.rows.length > 0) {
    const err = new Error(`License number '${license_number}' is already registered.`);
    err.status = 400;
    throw err;
  }

  const result = await db.query(
    `INSERT INTO drivers (name, license_number, license_expiry_date, status, safety_score)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [name, license_number, license_expiry_date, status || 'Available', safety_score || 100]
  );

  return result.rows[0];
};

/**
 * Update driver.
 */
const updateDriver = async (id, driverData) => {
  const { name, license_number, license_expiry_date, status, safety_score } = driverData;

  const existing = await db.query('SELECT * FROM drivers WHERE id = $1', [id]);
  if (existing.rows.length === 0) {
    const err = new Error('Driver not found.');
    err.status = 404;
    throw err;
  }

  const duplicateCheck = await db.query(
    'SELECT id FROM drivers WHERE license_number = $1 AND id != $2',
    [license_number, id]
  );
  if (duplicateCheck.rows.length > 0) {
    const err = new Error(`License number '${license_number}' is already in use by another driver.`);
    err.status = 400;
    throw err;
  }

  const result = await db.query(
    `UPDATE drivers 
     SET name = $1, license_number = $2, license_expiry_date = $3, status = $4, safety_score = $5
     WHERE id = $6
     RETURNING *`,
    [name, license_number, license_expiry_date, status, safety_score, id]
  );

  return result.rows[0];
};

/**
 * Delete driver.
 */
const deleteDriver = async (id) => {
  const existing = await db.query('SELECT * FROM drivers WHERE id = $1', [id]);
  if (existing.rows.length === 0) {
    const err = new Error('Driver not found.');
    err.status = 404;
    throw err;
  }

  await db.query('DELETE FROM drivers WHERE id = $1', [id]);
  return true;
};

/**
 * Get drivers eligible for dispatch.
 * Excludes suspended drivers or those with expired licenses.
 */
const getEligibleDrivers = async () => {
  const result = await db.query(
    `SELECT * FROM drivers 
     WHERE status = 'Available' 
       AND license_expiry_date > CURRENT_DATE
     ORDER BY name ASC`
  );
  return result.rows;
};

module.exports = {
  getAllDrivers,
  getDriverById,
  createDriver,
  updateDriver,
  deleteDriver,
  getEligibleDrivers,
};
