const { pool } = require('../db/pool');

/**
 * Get all maintenance logs.
 */
const getAllMaintenanceLogs = async () => {
  const result = await pool.query(
    `SELECT m.*, v.registration_number, v.model AS vehicle_model 
     FROM maintenance_logs m
     JOIN vehicles v ON m.vehicle_id = v.id
     ORDER BY m.id DESC`
  );
  return result.rows;
};

/**
 * Create a new maintenance record and mark the vehicle as 'In Shop'.
 */
const createMaintenanceLog = async (logData) => {
  const { vehicle_id, description, cost, status } = logData;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Check if vehicle exists
    const vehCheck = await client.query('SELECT status FROM vehicles WHERE id = $1 FOR UPDATE', [vehicle_id]);
    if (vehCheck.rows.length === 0) {
      throw new Error('Selected vehicle does not exist.');
    }
    
    const currentStatus = vehCheck.rows[0].status;
    if (currentStatus === 'Retired') {
      throw new Error('Cannot log maintenance: Selected vehicle is Retired.');
    }
    if (currentStatus === 'On Trip') {
      throw new Error('Cannot log maintenance: Vehicle is currently on an active trip.');
    }

    // Insert maintenance log
    const logResult = await client.query(
      `INSERT INTO maintenance_logs (vehicle_id, description, cost, status, logged_at)
       VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
       RETURNING *`,
      [vehicle_id, description, cost || 0.00, status || 'Pending']
    );

    // Flip vehicle status to 'In Shop'
    await client.query("UPDATE vehicles SET status = 'In Shop' WHERE id = $1", [vehicle_id]);

    await client.query('COMMIT');
    return logResult.rows[0];
  } catch (error) {
    await client.query('ROLLBACK');
    error.status = error.status || 400;
    throw error;
  } finally {
    client.release();
  }
};

/**
 * Close/complete a maintenance log. Restores vehicle to 'Available' (unless Retired).
 */
const closeMaintenanceLog = async (logId, closingData) => {
  const { cost } = closingData;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Get maintenance log details
    const logCheck = await client.query('SELECT * FROM maintenance_logs WHERE id = $1 FOR UPDATE', [logId]);
    if (logCheck.rows.length === 0) {
      throw new Error('Maintenance record not found.');
    }
    const log = logCheck.rows[0];
    if (log.status === 'Completed') {
      throw new Error('Maintenance record is already closed/completed.');
    }

    const finalCost = cost !== undefined ? parseFloat(cost) : parseFloat(log.cost);
    if (isNaN(finalCost) || finalCost < 0) {
      throw new Error('Please enter a valid non-negative maintenance cost.');
    }

    // Update maintenance log to Completed
    const logResult = await client.query(
      `UPDATE maintenance_logs 
       SET status = 'Completed', cost = $1, completed_at = CURRENT_TIMESTAMP 
       WHERE id = $2 
       RETURNING *`,
      [finalCost, logId]
    );

    // Get vehicle status
    const vehCheck = await client.query('SELECT status FROM vehicles WHERE id = $1', [log.vehicle_id]);
    if (vehCheck.rows.length > 0) {
      const vehicle = vehCheck.rows[0];
      // Unless the vehicle has been marked Retired, restore it to Available
      if (vehicle.status !== 'Retired') {
        await client.query("UPDATE vehicles SET status = 'Available' WHERE id = $1", [log.vehicle_id]);
      }
    }

    await client.query('COMMIT');
    return logResult.rows[0];
  } catch (error) {
    await client.query('ROLLBACK');
    error.status = error.status || 400;
    throw error;
  } finally {
    client.release();
  }
};

module.exports = {
  getAllMaintenanceLogs,
  createMaintenanceLog,
  closeMaintenanceLog,
};
