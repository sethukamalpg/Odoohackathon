/**
 * Express middleware to restrict routes to specific roles.
 * @param {string[]} allowedRoles - Array of allowed role names (e.g. ['Admin', 'Manager'])
 */
const requireRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized. Authentication required.' });
    }

    const userRole = req.user.role; // Name of the role (e.g., 'Admin', 'Dispatcher', 'Manager')
    
    if (!allowedRoles.includes(userRole)) {
      return res.status(403).json({ error: 'Access denied. Insufficient permissions.' });
    }

    next();
  };
};

module.exports = requireRole;
