const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRouter = require('./routes/auth');

const app = express();
const PORT = process.env.AUTH_PORT || 5001;

// Middlewares
app.use(cors());
app.use(express.json());

// Routes
app.use('/auth', authRouter);

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', service: 'authentication' });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Authentication server is running on port ${PORT}`);
});
