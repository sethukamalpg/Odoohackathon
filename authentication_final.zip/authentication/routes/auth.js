const express = require('express');
const router = express.Router();
const db = require('../db');
const { hashPassword, comparePassword } = require('../utils/bcrypt');
const { generateToken } = require('../utils/jwt');
const verifyToken = require('../middleware/verifyToken');

// Regular expression for basic email validation
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * @route POST /auth/register
 * @desc Register a new user
 */
router.post('/register', async (req, res) => {
  const { name, email, password, roleName } = req.body;

  // Validation
  if (!name || name.trim() === '') {
    return res.status(400).json({ error: 'Please enter your name.' });
  }

  if (!email || !emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  if (!password || password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
  }

  const role = roleName || 'Dispatcher'; // Default role if not provided

  try {
    // Check if role exists
    const roleRes = await db.query('SELECT id FROM roles WHERE name = $1', [role]);
    if (roleRes.rows.length === 0) {
      return res.status(400).json({ error: `The selected role '${role}' is invalid.` });
    }
    const roleId = roleRes.rows[0].id;

    // Check if email already exists
    const userExists = await db.query('SELECT id FROM users WHERE email = $1', [email]);
    if (userExists.rows.length > 0) {
      return res.status(400).json({ error: 'An account with this email address already exists.' });
    }

    // Hash password and save
    const passwordHash = await hashPassword(password);
    const newUser = await db.query(
      'INSERT INTO users (name, email, password_hash, role_id) VALUES ($1, $2, $3, $4) RETURNING id, name, email, role_id',
      [name, email, passwordHash, roleId]
    );

    // Generate token
    const token = generateToken({
      id: newUser.rows[0].id,
      name: newUser.rows[0].name,
      email: newUser.rows[0].email,
      role: role,
    });

    return res.status(201).json({
      message: 'Account registered successfully.',
      token,
      user: {
        id: newUser.rows[0].id,
        name: newUser.rows[0].name,
        email: newUser.rows[0].email,
        role: role,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    return res.status(500).json({ error: 'A server error occurred. Please try again later.' });
  }
});

/**
 * @route POST /auth/login
 * @desc Login user
 */
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  // Validation
  if (!email || !emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  if (!password) {
    return res.status(400).json({ error: 'Please enter your password.' });
  }

  try {
    // Find user with role
    const userRes = await db.query(
      `SELECT u.id, u.name, u.email, u.password_hash, r.name AS role 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.email = $1`,
      [email]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'Incorrect email or password.' });
    }

    const user = userRes.rows[0];

    // Compare passwords
    const isMatch = await comparePassword(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Incorrect email or password.' });
    }

    // Generate token
    const token = generateToken({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    });

    return res.status(200).json({
      message: 'Login successful.',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'A server error occurred. Please try again later.' });
  }
});

/**
 * @route GET /auth/me
 * @desc Get current authenticated user profile
 */
router.get('/me', verifyToken, async (req, res) => {
  try {
    const userRes = await db.query(
      `SELECT u.id, u.name, u.email, r.name AS role 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.id = $1`,
      [req.user.id]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: 'User profile not found.' });
    }

    return res.status(200).json({
      user: userRes.rows[0],
    });
  } catch (error) {
    console.error('Get profile error:', error);
    return res.status(500).json({ error: 'A server error occurred. Please try again later.' });
  }
});

module.exports = router;
